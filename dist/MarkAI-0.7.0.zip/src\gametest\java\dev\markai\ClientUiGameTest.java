package dev.markai;

import com.mojang.blaze3d.platform.InputConstants;
import dev.markai.ai.LlmProvider;
import dev.markai.ai.OllamaClient;
import dev.markai.client.ClientCompanionState;
import dev.markai.client.CompanionScreen;
import dev.markai.client.MarkAIClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.animal.wolf.Wolf;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** Actual native UI, real owner packets and screenshots, with a deterministic AI provider. */
@Environment(EnvType.CLIENT)
public final class ClientUiGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext context) {
        var pending = new CompletableFuture<OllamaClient.Reply>();
        var calls = new AtomicInteger();
        LlmProvider fake = new LlmProvider() {
            @Override public CompletableFuture<OllamaClient.Reply> ask(String observation, String question, List<OllamaClient.ChatMessage> history) {
                return calls.incrementAndGet() == 1 ? CompletableFuture.completedFuture(new OllamaClient.Reply("say", "Запомнил: тебе нравятся берёзовые дома.")) : pending;
            }
            @Override public void close() { pending.cancel(true); }
        };
        try (var world = context.worldBuilder().create()) {
            var server = world.getServer(); var connection = world.getConnection();
            UUID ownerId = context.computeOnClient(client -> client.player.getUUID());
            MarkAIMod mod = mod(); Field provider = field(MarkAIMod.class, "ollama");
            var original = new AtomicReference<LlmProvider>();
            var restorePreferences = new AtomicReference<Runnable>(() -> { });
            server.runOnServer(instance -> {
                try { original.set((LlmProvider) provider.get(mod)); provider.set(mod, fake); }
                catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
                ServerPlayer owner = instance.getPlayerList().getPlayer(ownerId);
                instance.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark spawn");
                try {
                    var companion = (MarkAIMod.Companion) ((Map<?, ?>) field(MarkAIMod.class, "companions").get(mod)).get(ownerId);
                    String name = companion.living.name;
                    boolean hud = companion.living.settings.hud;
                    double loyalty = companion.living.personality.loyalty;
                    Wolf testWolf = wolf(owner);
                    restorePreferences.set(() -> {
                        companion.living.name = name; companion.living.settings.hud = hud; companion.living.personality.loyalty = loyalty;
                        if (testWolf.isAlive()) testWolf.setCustomName(net.minecraft.network.chat.Component.literal(name));
                    });
                } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
            });
            try {
                connection.waitForClientboundEntityUpdates(net.minecraft.world.entity.EntityTypes.WOLF);
                context.getInput().pressKey(KeyMapping.get("key.markai.open"));
                context.waitForScreen(CompanionScreen.class);
                context.waitFor(client -> MarkAIClient.STATE.received() && MarkAIClient.preview() != null);
                context.takeScreenshot("markai-profile");
                context.clickScreenButton("markai.tab.commands");
                pace(context); context.clickScreenButton("markai.command.stay"); connection.waitForServerboundPackets();
                server.waitFor(instance -> wolf(instance.getPlayerList().getPlayer(ownerId)).isOrderedToSit());
                context.waitFor(client -> MarkAIClient.STATE.string("activity", "").equals("STAY"));
                pace(context); context.clickScreenButton("markai.command.follow"); connection.waitForServerboundPackets();
                server.waitFor(instance -> !wolf(instance.getPlayerList().getPlayer(ownerId)).isOrderedToSit());
                context.waitFor(client -> !MarkAIClient.STATE.string("activity", "STAY").equals("STAY"));
                context.takeScreenshot("markai-commands");

                context.clickScreenButton("markai.tab.dialogue");
                context.getInput().typeChars("Запомни: я люблю берёзовые дома.");
                assertDraftSurvivesResize(context, "Запомни: я люблю берёзовые дома.");
                pace(context); context.clickScreenButton("markai.ui.send"); connection.waitForServerboundPackets();
                context.waitFor(client -> MarkAIClient.STATE.messages().size() >= 2);
                check(calls.get() == 1, "GUI Send must call the server provider once");
                context.takeScreenshot("markai-dialogue");
                server.runOnServer(instance -> resetCooldown(mod, ownerId));
                long chatReady = System.nanoTime() + 1_150_000_000L;
                while (System.nanoTime() < chatReady) context.waitTick();
                context.getInput().typeChars("Что скажешь?");
                pace(context); context.clickScreenButton("markai.ui.send"); connection.waitForServerboundPackets();
                context.waitFor(client -> calls.get() == 2);
                context.waitFor(client -> !MarkAIClient.STATE.bool("can_chat", true));
                context.getInput().typeChars("Следующий вопрос");
                context.runOnClient(client -> {
                    client.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_RETURN, 0, 0));
                    check(editBox(client.gui.screen()).getValue().equals("Следующий вопрос"), "Enter while Mark is thinking must preserve the next draft");
                });
                pace(context); context.clickScreenButton("markai.ui.cancel"); connection.waitForServerboundPackets();
                context.waitFor(client -> pending.isCancelled());
                context.runOnClient(client -> { MarkAIClient.cancel(); MarkAIClient.cancel(); });
                connection.waitForServerboundPackets();
                context.waitFor(client -> MarkAIClient.STATE.notice().contains("Повторите действие через секунду"));
                context.runOnClient(client -> MarkAIClient.STATE.notice("status", ""));

                context.clickScreenButton("markai.tab.memories");
                context.waitFor(client -> MarkAIClient.STATE.memories().toString().contains("берёзовые"));
                clickMatching(context, "люблю", false);
                context.takeScreenshot("markai-memories");
                pace(context); context.clickScreenButton("markai.ui.delete"); connection.waitForServerboundPackets();
                context.waitFor(client -> !MarkAIClient.STATE.memories().toString().contains("берёзовые"));

                context.clickScreenButton("markai.tab.settings");
                boolean hud = context.computeOnClient(client -> ClientCompanionState.bool(MarkAIClient.STATE.settings(), "hud", true));
                pace(context); clickMatching(context, text("markai.setting.hud"), true); connection.waitForServerboundPackets();
                context.waitFor(client -> ClientCompanionState.bool(MarkAIClient.STATE.settings(), "hud", true) != hud);
                context.runOnClient(client -> editBox(client.gui.screen()).setValue(""));
                assertDraftSurvivesResize(context, "");
                context.runOnClient(client -> {
                    var screen = client.gui.screen();
                    screen.tick();
                    Button rename = screen.children().stream().filter(widget -> widget instanceof Button).map(widget -> (Button) widget)
                        .filter(button -> button.getMessage().getString().equals(text("markai.ui.rename"))).findFirst().orElseThrow();
                    check(!rename.active, "A blank companion name must disable Rename");
                    editBox(screen).setValue("   ");
                    screen.tick();
                    check(!rename.active, "A whitespace companion name must disable Rename");
                    editBox(screen).setValue("Марк Тест");
                    screen.tick();
                    check(rename.active, "A valid companion name must enable Rename");
                });
                assertDraftSurvivesResize(context, "Марк Тест");
                pace(context); context.clickScreenButton("markai.ui.rename"); connection.waitForServerboundPackets();
                context.waitFor(client -> MarkAIClient.STATE.string("name", "").equals("Марк Тест"));
                context.takeScreenshot("markai-settings");
                context.clickScreenButton("markai.ui.personality");
                double loyalty = context.computeOnClient(client -> ClientCompanionState.number(MarkAIClient.STATE.traits(), "loyalty", 50));
                pace(context); clickMatching(context, text("markai.trait.loyalty"), true); connection.waitForServerboundPackets();
                context.waitFor(client -> ClientCompanionState.number(MarkAIClient.STATE.traits(), "loyalty", 50) != loyalty);
                context.takeScreenshot("markai-personality");

                context.clickScreenButton("markai.tab.commands");
                pace(context); context.clickScreenButton("markai.command.inventory"); connection.waitForServerboundPackets();
                context.waitFor(client -> client.gui.screen() instanceof AbstractContainerScreen<?>);
                context.takeScreenshot("markai-inventory");
                context.runOnClient(client -> client.player.closeContainer()); context.waitForScreen(null);
                context.getInput().pressKey(KeyMapping.get("key.markai.dialogue")); context.waitForScreen(CompanionScreen.class);
                context.runOnClient(client -> check(client.gui.screen().children().stream().anyMatch(widget -> widget instanceof EditBox), "H must open dialogue input"));
                context.setScreen(() -> null);
                context.getInput().pressKey(KeyMapping.get("key.markai.quick")); context.waitForScreen(CompanionScreen.class);
                context.takeScreenshot("markai-quick-commands"); context.setScreen(() -> null);
                pace(context); context.runOnClient(client -> MarkAIClient.setting("hud", "true")); connection.waitForServerboundPackets();
                context.waitFor(client -> ClientCompanionState.bool(MarkAIClient.STATE.settings(), "hud", false));
                context.waitTicks(5); context.takeScreenshot("markai-hud");
            } finally {
                server.runOnServer(instance -> {
                    restorePreferences.get().run();
                    try { provider.set(mod, original.get()); } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
                });
                fake.close();
            }
        }
        context.waitFor(client -> client.getConnection() == null);
        context.runOnClient(client -> {
            check(!MarkAIClient.chat("Привет"), "Disconnected chat must report that nothing was sent");
            check(MarkAIClient.STATE.errorNotice() && MarkAIClient.STATE.notice().equals(text("markai.ui.no_server")),
                "The no-server error must not be replaced by a sent notice");
            MarkAIClient.STATE.clear();
        });
    }
    private static EditBox editBox(net.minecraft.client.gui.screens.Screen screen) {
        return screen.children().stream().filter(widget -> widget instanceof EditBox).map(widget -> (EditBox) widget).findFirst().orElseThrow();
    }
    private static void assertDraftSurvivesResize(ClientGameTestContext context, String draft) {
        context.runOnClient(client -> {
            var screen = client.gui.screen();
            int width = screen.width, height = screen.height;
            screen.resize(width - 20, height - 20);
            check(editBox(screen).getValue().equals(draft), "Resizing must preserve unsent text");
            screen.resize(width, height);
            check(editBox(screen).getValue().equals(draft), "Restoring the size must preserve unsent text");
        });
    }
    private static void pace(ClientGameTestContext context) {
        // Test ticks may run faster than the wall-clock packet rate limit.
        long until = System.nanoTime() + 350_000_000L;
        while (System.nanoTime() < until) context.waitTick();
    }
    private static void clickMatching(ClientGameTestContext context, String value, boolean prefix) {
        String label = context.computeOnClient(client -> client.gui.screen().children().stream().filter(widget -> widget instanceof Button)
            .map(widget -> (Button) widget).filter(button -> button.active && (prefix ? button.getMessage().getString().startsWith(value) : button.getMessage().getString().contains(value)))
            .findFirst().orElseThrow().getMessage().getString());
        context.clickScreenButton(label);
    }
    private static String text(String key) { return net.minecraft.network.chat.Component.translatable(key).getString(); }
    private static Wolf wolf(ServerPlayer owner) {
        return owner.level().getEntitiesOfClass(Wolf.class, owner.getBoundingBox().inflate(16)).stream()
            .filter(wolf -> wolf.isAlive() && wolf.isOwnedBy(owner)).findFirst().orElseThrow();
    }
    private static MarkAIMod mod() {
        return (MarkAIMod) FabricLoader.getInstance().getEntrypoints("main", ModInitializer.class).stream()
            .filter(value -> value instanceof MarkAIMod).findFirst().orElseThrow();
    }
    private static Field field(Class<?> owner, String name) {
        try { Field field = owner.getDeclaredField(name); field.setAccessible(true); return field; }
        catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
    }
    private static void resetCooldown(MarkAIMod mod, UUID owner) {
        try {
            Object session = ((Map<?, ?>) field(MarkAIMod.class, "aiSessions").get(mod)).get(owner);
            field(session.getClass(), "nextRequest").setLong(session, 0);
        } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
