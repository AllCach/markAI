package dev.markai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.markai.brain.MarkBrain;
import dev.markai.ai.AIConfig;
import dev.markai.ai.OllamaClient;
import dev.markai.mixin.MobAccessor;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import com.mojang.brigadier.arguments.StringArgumentType;

public final class MarkAIMod implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("markai");
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson CHAT_JSON = new GsonBuilder().disableHtmlEscaping().create();
    private final Map<UUID, Companion> companions = new HashMap<>();
    private final Set<UUID> configured = new HashSet<>();
    private MinecraftServer server;
    private int ticks;
    private boolean storageHealthy;
    private AIConfig aiConfig;
    private OllamaClient ollama;
    private final Map<UUID, AISession> aiSessions = new HashMap<>();

    private static final class AISession {
        boolean enabled = true;
        long generation;
        long nextRequest;
        long idleUntil, wanderUntil, lookUntil, fleeUntil;
        CompletableFuture<OllamaClient.Reply> pending;
        final ArrayDeque<OllamaClient.ChatMessage> history = new ArrayDeque<>();
    }

    public static final class Companion {
        UUID owner;
        UUID entity;
        String dimension;
        int chunkX, chunkZ;
        boolean dead;
        boolean following = true;
        transient long nextMessage;
        transient String action = "IDLE";
    }

    @Override public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            companions.clear();
            configured.clear();
            ticks = 0;
            aiSessions.clear();
            try {
                aiConfig = AIConfig.load(FabricLoader.getInstance().getConfigDir().resolve("markai.json"));
                ollama = new OllamaClient(aiConfig.ollamaUrl, aiConfig.ollamaModel, Duration.ofSeconds(aiConfig.timeoutSeconds));
            } catch (Exception e) {
                ollama = null;
                LOG.error("Cannot initialize local AI; deterministic companion behavior remains available", e);
            }
            storageHealthy = true;
            Path path = statePath();
            if (Files.exists(path)) {
                try {
                    Companion[] saved = JSON.fromJson(Files.readString(path), Companion[].class);
                    if (saved == null) throw new IOException("Empty state file");
                    for (Companion c : saved) {
                        if (c.owner == null || c.entity == null || c.dimension == null)
                            throw new IOException("Invalid companion state");
                        companions.put(c.owner, c);
                    }
                } catch (Exception e) {
                    storageHealthy = false;
                    LOG.error("Cannot load MarkAI state; spawning disabled to prevent duplicates", e);
                }
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            for (AISession session : aiSessions.values()) invalidate(session);
            aiSessions.clear();
            if (ollama != null) { ollama.close(); ollama = null; }
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            companions.clear(); configured.clear(); server = null;
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            AISession ownerSession = aiSessions.get(entity.getUUID());
            if (ownerSession != null) invalidate(ownerSession);
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                remember(c, entity, level); configured.remove(c.entity); save();
                AISession session = aiSessions.get(c.owner);
                if (session != null) invalidate(session);
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            AISession ownerSession = aiSessions.get(entity.getUUID());
            if (ownerSession != null) invalidate(ownerSession);
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                c.dead = true; configured.remove(c.entity); save();
                AISession session = aiSessions.get(c.owner);
                if (session != null) invalidate(session);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (++ticks % 10 != 0) return;
            for (Companion c : companions.values()) tick(c);
            if (ticks % 200 == 0) save();
        });
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.signedContent().strip();
            String lower = text.toLowerCase(Locale.ROOT);
            for (String prefix : List.of("марк,", "марк:", "mark,", "mark:")) {
                if (lower.startsWith(prefix)) {
                    ask(sender, text.substring(prefix.length()).strip());
                    break;
                }
            }
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            var root = Commands.literal("mark").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "/mark spawn | follow | stay | status | respawn | ask <сообщение> | ai on/off/status. Ник указывать не нужно."), false);
                return 1;
            });
            for (String name : List.of("spawn", "respawn", "follow", "stay", "status")) {
                root.then(Commands.literal(name).executes(ctx -> command(ctx, name)));
            }
            root.then(Commands.literal("ask").then(Commands.argument("message", StringArgumentType.greedyString())
                .executes(ctx -> ask(ctx.getSource().getPlayerOrException(), StringArgumentType.getString(ctx, "message")))));
            var ai = Commands.literal("ai").executes(ctx -> aiCommand(ctx.getSource().getPlayerOrException(), "status"));
            for (String mode : List.of("on", "off", "status"))
                ai.then(Commands.literal(mode).executes(ctx -> aiCommand(ctx.getSource().getPlayerOrException(), mode)));
            root.then(ai);
            dispatcher.register(root);
        });
    }

    private int command(CommandContext<CommandSourceStack> context, String command) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer owner = context.getSource().getPlayerOrException();
        if (!storageHealthy) {
            owner.sendSystemMessage(Component.literal("MarkAI: ошибка файла состояния; см. журнал. Создание отключено."));
            return 0;
        }
        Companion c = companions.get(owner.getUUID());
        if (command.equals("spawn") || command.equals("respawn")) {
            if (c != null && !c.dead) {
                // Resolve the saved chunk before deciding anything about an unloaded companion.
                for (ServerLevel level : server.getAllLevels()) {
                    if (level.dimension().identifier().toString().equals(c.dimension))
                        level.getChunk(c.chunkX, c.chunkZ);
                }
                Chicken existing = find(c);
                owner.sendSystemMessage(Component.literal(existing != null
                    ? "Марк уже существует: " + c.entity
                    : "Марк сохранён, но пока не найден. Повторный спавн запрещён: " + c.entity));
                return existing != null ? 1 : 0;
            }
            ServerLevel level = (ServerLevel) owner.level();
            Chicken chicken = EntityTypes.CHICKEN.create(level, EntitySpawnReason.COMMAND);
            if (chicken == null) return 0;
            Vec3 pos = owner.position().add(1, 0, 1);
            chicken.setPos(pos.x, pos.y, pos.z);
            if (!level.noCollision(chicken) || !level.getFluidState(chicken.blockPosition()).isEmpty()) {
                owner.sendSystemMessage(Component.literal("Для Марка нужно свободное сухое место рядом с игроком."));
                return 0;
            }
            chicken.setCustomName(Component.literal("Марк"));
            chicken.setCustomNameVisible(true);
            chicken.getAttribute(Attributes.MAX_HEALTH).setBaseValue(4);
            chicken.setHealth(4);
            chicken.setPersistenceRequired();
            chicken.setAge(0);
            if (!level.addFreshEntity(chicken)) return 0;
            c = new Companion(); c.owner = owner.getUUID(); c.entity = chicken.getUUID();
            remember(c, chicken, level);
            companions.put(c.owner, c);
            configure(chicken);
            save();
            owner.sendSystemMessage(Component.literal("Марк создан. Владелец: " + c.owner));
            return 1;
        }
        if (c == null) {
            owner.sendSystemMessage(Component.literal("Сначала выполните /mark spawn.")); return 0;
        }
        if (command.equals("status")) {
            Chicken chicken = find(c);
            owner.sendSystemMessage(Component.literal("Марк | owner=" + c.owner + " | entity=" + c.entity
                + " | minecraft:chicken | HP=" + (chicken == null ? "?" : chicken.getHealth())
                + "/4 | " + (c.dead ? "DEAD" : chicken == null ? "UNLOADED" : c.action)
                + " | mode=" + (c.following ? "FOLLOW" : "STAY") + " | dimension=" + c.dimension));
        } else {
            invalidate(aiSessions.computeIfAbsent(c.owner, key -> new AISession()));
            c.following = command.equals("follow");
            Chicken chicken = find(c);
            if (chicken != null) { configure(chicken); chicken.getNavigation().stop(); }
            save();
            owner.sendSystemMessage(Component.literal(c.following ? "Марк следует за вами." : "Марк остаётся на месте; при угрозе убегает."));
        }
        return 1;
    }

    private void configure(Chicken chicken) {
        if (configured.add(chicken.getUUID())) {
            ((MobAccessor) chicken).markai$goals().removeAllGoals(goal -> true);
        }
    }

    private Chicken find(Companion c) {
        if (c.dead) return null;
        for (ServerLevel level : server.getAllLevels()) {
            Entity entity = level.getEntity(c.entity);
            if (entity instanceof Chicken chicken && chicken.isAlive()) return chicken;
        }
        return null;
    }

    private void tick(Companion c) {
        Chicken chicken = find(c);
        if (chicken == null) return;
        configure(chicken);
        ServerLevel level = (ServerLevel) chicken.level();
        remember(c, chicken, level);
        ServerPlayer owner = server.getPlayerList().getPlayer(c.owner);
        if (owner == null || !owner.isAlive() || owner.level() != level) {
            chicken.getNavigation().stop(); c.action = "IDLE"; return;
        }
        Entity enemy = level.getEntities(chicken, chicken.getBoundingBox().inflate(12),
                e -> e instanceof Enemy && e.isAlive()).stream()
            .min(Comparator.comparingDouble(chicken::distanceToSqr)).orElse(null);
        MarkBrain.Decision decision = MarkBrain.think(new MarkBrain.WorldState(
            owner.getGameProfile().name(), chicken.distanceTo(owner),
            enemy == null ? Double.POSITIVE_INFINITY : chicken.distanceTo(enemy), (int) chicken.getHealth()));
        String action = decision.action();
        long now = level.getGameTime();
        AISession session = aiSessions.get(c.owner);
        if (!c.following && !action.equals("FLEE")) action = "IDLE";
        if (!action.equals("FLEE") && session != null) {
            if (session.fleeUntil > now && enemy != null) action = "FLEE";
            else if (session.idleUntil > now || session.lookUntil > now) action = "IDLE";
            else if (session.wanderUntil > now) action = "WANDER";
        }
        switch (action) {
            case "FLEE" -> {
                // Vanilla's escape-position sampler accounts for terrain and reachable ground.
                if (chicken.getNavigation().isDone() || !"FLEE".equals(c.action)) {
                    for (int attempt = 0; attempt < 8; attempt++) {
                        Vec3 target = DefaultRandomPos.getPosAway(chicken, 12, 5, enemy.position());
                        if (target != null && target.distanceToSqr(enemy.position()) > chicken.distanceToSqr(enemy)
                                && chicken.getNavigation().moveTo(target.x, target.y, target.z, 1.5)) break;
                    }
                }
            }
            case "FOLLOW" -> chicken.getNavigation().moveTo(owner, 1.2);
            case "WANDER" -> {
                if (chicken.getNavigation().isDone()) {
                    Vec3 target = DefaultRandomPos.getPos(chicken, 5, 3);
                    if (target != null) chicken.getNavigation().moveTo(target.x, target.y, target.z, 1.0);
                }
            }
            default -> chicken.getNavigation().stop();
        }
        if (session != null && session.lookUntil > now && !action.equals("FLEE"))
            chicken.getLookControl().setLookAt(owner, 30, 30);
        if (!action.equals(c.action) && action.equals(decision.action())
                && (action.equals("FLEE") || action.equals("FOLLOW")) && now >= c.nextMessage) {
            owner.sendSystemMessage(Component.literal("<Марк> " + decision.message()));
            c.nextMessage = now + 200;
        }
        c.action = action;
    }

    private int aiCommand(ServerPlayer owner, String mode) {
        AISession session = aiSessions.computeIfAbsent(owner.getUUID(), key -> new AISession());
        if (!mode.equals("status")) {
            invalidate(session);
            session.enabled = mode.equals("on");
            session.history.clear();
        }
        owner.sendSystemMessage(Component.literal("Марк: ИИ " + (session.enabled ? "включён" : "выключен")
            + ", модель=" + (aiConfig == null ? "ошибка конфига" : aiConfig.ollamaModel)
            + (ollama == null ? ", клиент недоступен; см. журнал" : "")
            + (session.pending == null ? "" : ", ожидаю ответ")
            + ". Обращение: /mark ask <текст> или Марк, <текст>."));
        return 1;
    }

    private static void invalidate(AISession session) {
        session.generation++;
        if (session.pending != null) { session.pending.cancel(true); session.pending = null; }
        session.idleUntil = session.wanderUntil = session.lookUntil = session.fleeUntil = 0;
    }

    private int ask(ServerPlayer owner, String message) {
        if (!storageHealthy) {
            owner.sendSystemMessage(Component.literal("MarkAI: ошибка файла состояния; см. журнал.")); return 0;
        }
        Companion c = companions.get(owner.getUUID());
        Chicken chicken = c == null ? null : find(c);
        if (chicken == null || !owner.isAlive() || chicken.level() != owner.level()) {
            owner.sendSystemMessage(Component.literal("Марк должен быть жив и загружен в вашем измерении. Проверьте /mark status."));
            return 0;
        }
        AISession session = aiSessions.computeIfAbsent(c.owner, key -> new AISession());
        if (!session.enabled || ollama == null) {
            owner.sendSystemMessage(Component.literal("ИИ недоступен. /mark ai on; настройки: config/markai.json.")); return 0;
        }
        if (message.isBlank() || message.length() > 512) {
            owner.sendSystemMessage(Component.literal("Сообщение Марку: от 1 до 512 символов.")); return 0;
        }
        long nowMillis = System.currentTimeMillis();
        if (session.pending != null || aiSessions.values().stream().anyMatch(s -> s.pending != null)
                || nowMillis < session.nextRequest) {
            owner.sendSystemMessage(Component.literal("Марк ещё думает. Подождите немного.")); return 0;
        }
        session.nextRequest = nowMillis + aiConfig.requestCooldownSeconds * 1000L;
        MinecraftServer requestServer = server;
        UUID entityUuid = c.entity;
        var requestLevel = chicken.level();
        long generation = ++session.generation;
        String context = snapshot(c, chicken, owner);
        var pending = ollama.ask(context, message, List.copyOf(session.history));
        session.pending = pending;
        owner.sendSystemMessage(Component.literal("Марк думает…"));
        pending.whenComplete((reply, error) -> {
            try {
                requestServer.execute(() -> {
                    if (server != requestServer || aiSessions.get(c.owner) != session || session.generation != generation) return;
                    session.pending = null;
                    if (!session.enabled || companions.get(c.owner) != c || !entityUuid.equals(c.entity)) return;
                    ServerPlayer currentOwner = requestServer.getPlayerList().getPlayer(c.owner);
                    Chicken current = find(c);
                    if (currentOwner != owner || !currentOwner.isAlive() || current == null
                            || current.level() != requestLevel || current.level() != currentOwner.level()) return;
                    if (error != null) {
                        LOG.warn("Local AI request failed: {}", error.toString());
                        currentOwner.sendSystemMessage(Component.literal("<Марк> Сейчас не могу ответить. Проверь Ollama; я продолжу действовать по обстановке."));
                        return;
                    }
                    applyReply(c, current, currentOwner, session, reply);
                    session.history.addLast(new OllamaClient.ChatMessage("user", message));
                    session.history.addLast(new OllamaClient.ChatMessage("assistant", CHAT_JSON.toJson(reply)));
                    while (session.history.size() > 8) session.history.removeFirst();
                });
            } catch (java.util.concurrent.RejectedExecutionException ignored) {
                // The owning logical server has stopped; never apply this result elsewhere.
            }
        });
        return 1;
    }

    private String snapshot(Companion c, Chicken chicken, ServerPlayer owner) {
        var level = (ServerLevel) chicken.level();
        var hostiles = level.getEntities(chicken, chicken.getBoundingBox().inflate(12), e -> e instanceof Enemy && e.isAlive())
            .stream().sorted(Comparator.comparingDouble(chicken::distanceToSqr)).limit(5)
            .map(e -> Map.of("type", e.getType().toString(), "distance_blocks", chicken.distanceTo(e))).toList();
        return JSON.toJson(Map.of(
            "companion", Map.of("name", "Марк", "type", "minecraft:chicken", "health", chicken.getHealth(), "max_health", 4),
            "player", Map.of("name", owner.getGameProfile().name(), "distance_blocks", chicken.distanceTo(owner)),
            "nearby_hostiles", hostiles, "mode", c.following ? "follow" : "stay",
            "dimension", c.dimension));
    }

    private void applyReply(Companion c, Chicken chicken, ServerPlayer owner, AISession session, OllamaClient.Reply reply) {
        long now = chicken.level().getGameTime();
        session.idleUntil = session.wanderUntil = session.lookUntil = session.fleeUntil = 0;
        switch (reply.action()) {
            case "follow" -> { c.following = true; save(); }
            case "stay" -> { c.following = false; stopUnlessFleeing(c, chicken); save(); }
            case "idle" -> { session.idleUntil = now + 100; stopUnlessFleeing(c, chicken); }
            case "look_at_player" -> { session.lookUntil = now + 100; stopUnlessFleeing(c, chicken); }
            case "wander" -> session.wanderUntil = now + 100;
            case "flee" -> session.fleeUntil = now + 100;
            case "say" -> { }
            default -> { return; }
        }
        if (!reply.say().isBlank()) {
            owner.sendSystemMessage(Component.literal("<Марк> " + reply.say()));
            c.nextMessage = now + 200;
        }
    }

    private void stopUnlessFleeing(Companion c, Chicken chicken) {
        if (!"FLEE".equals(c.action)) chicken.getNavigation().stop();
    }

    private void remember(Companion c, Entity entity, ServerLevel level) {
        c.dimension = level.dimension().identifier().toString();
        c.chunkX = entity.chunkPosition().x(); c.chunkZ = entity.chunkPosition().z();
    }

    private Path statePath() { return server.getWorldPath(LevelResource.ROOT).resolve("markai.json"); }

    private void save() {
        if (server == null || !storageHealthy) return;
        try {
            Path target = statePath(), temp = target.resolveSibling("markai.json.tmp");
            Files.writeString(temp, JSON.toJson(companions.values()));
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            storageHealthy = false;
            LOG.error("Cannot save MarkAI state; further commands disabled", e);
        }
    }
}
