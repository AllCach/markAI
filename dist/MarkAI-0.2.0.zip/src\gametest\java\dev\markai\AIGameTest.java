package dev.markai;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import dev.markai.ai.OllamaClient;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.gametest.framework.GameTestInfo;
import net.minecraft.gametest.framework.GameTestListener;
import net.minecraft.gametest.framework.GameTestRunner;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public final class AIGameTest {
    @GameTest(maxTicks = 2000)
    public void validatedReplyChangesOwnerMode(GameTestHelper helper) throws Exception {
        for (int x = 0; x < 7; x++) for (int z = 0; z < 7; z++)
            helper.setBlock(new BlockPos(x, 1, z), Blocks.STONE);
        var owner = helper.makeMockServerPlayerInLevel();
        Vec3 position = helper.absoluteVec(new Vec3(2, 2, 2));
        owner.setPos(position.x, position.y, position.z);
        var server = helper.getLevel().getServer();
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark spawn");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
        Path state = server.getWorldPath(LevelResource.ROOT).resolve("markai.json");
        String entityUuid = savedCompanion(state, owner.getUUID()).get("entity").getAsString();

        var firstRequest = new AtomicReference<String>();
        var secondRequest = new AtomicReference<String>();
        var requests = new AtomicInteger();
        var releaseSecondReply = new CountDownLatch(1);
        var secondReplyAttempted = new CountDownLatch(1);
        String longSay = "<".repeat(240);
        HttpServer fake = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var fakeExecutor = Executors.newVirtualThreadPerTaskExecutor();
        fake.setExecutor(fakeExecutor);
        fake.createContext("/api/chat", exchange -> {
            boolean second = false;
            try (exchange) {
                String request = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                second = requests.incrementAndGet() > 1;
                if (second) {
                    secondRequest.set(request);
                    try { releaseSecondReply.await(10, TimeUnit.SECONDS); }
                    catch (InterruptedException error) { Thread.currentThread().interrupt(); return; }
                } else firstRequest.set(request);
                JsonObject message = new JsonObject();
                message.addProperty("role", "assistant");
                message.addProperty("content", new Gson().toJson(new OllamaClient.Reply("follow", second ? "Иду!" : longSay)));
                JsonObject response = new JsonObject(); response.add("message", message); response.addProperty("done", true);
                byte[] body = response.toString().getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, body.length);
                exchange.getResponseBody().write(body);
            } catch (IOException ignored) {
                // Manual stay cancels the second HTTP request and may close its connection before this write.
            } finally {
                if (second) secondReplyAttempted.countDown();
            }
        });
        fake.start();

        MarkAIMod mod = (MarkAIMod) FabricLoader.getInstance().getEntrypoints("main", ModInitializer.class).stream()
            .filter(value -> value instanceof MarkAIMod).findFirst().orElseThrow();
        var clientField = MarkAIMod.class.getDeclaredField("ollama");
        clientField.setAccessible(true);
        var original = (OllamaClient) clientField.get(mod);
        var client = new OllamaClient("http://127.0.0.1:" + fake.getAddress().getPort(), "qwen3:8b", Duration.ofSeconds(5));
        var cleaned = new AtomicBoolean();
        Runnable cleanup = () -> {
            if (!cleaned.compareAndSet(false, true)) return;
            try {
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ai off");
                clientField.set(mod, original);
            } catch (IllegalAccessException error) { throw new RuntimeException(error); }
            finally {
                releaseSecondReply.countDown();
                client.close(); fake.stop(0); fakeExecutor.shutdownNow();
            }
        };
        // Restore the shared client even if an asynchronous assertion fails or the test times out.
        var infoField = GameTestHelper.class.getDeclaredField("testInfo");
        infoField.setAccessible(true);
        ((GameTestInfo) infoField.get(helper)).addListener(new GameTestListener() {
            @Override public void testStructureLoaded(GameTestInfo info) {}
            @Override public void testPassed(GameTestInfo info, GameTestRunner runner) { cleanup.run(); }
            @Override public void testFailed(GameTestInfo info, GameTestRunner runner) { cleanup.run(); }
            @Override public void testAddedForRerun(GameTestInfo oldInfo, GameTestInfo newInfo, GameTestRunner runner) { cleanup.run(); }
        });
        clientField.set(mod, client);
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ask Иди за мной");

        helper.startSequence()
            .thenWaitUntil(() -> {
                helper.assertTrue(firstRequest.get() != null, "AI request must be sent asynchronously");
                JsonObject saved = savedCompanion(state, owner.getUUID());
                helper.assertTrue(saved.get("following").getAsBoolean(), "Validated follow reply must change and persist owner mode");
                helper.assertTrue(saved.get("entity").getAsString().equals(entityUuid), "Reply must retain companion UUID");
                helper.assertTrue(firstRequest.get().contains(owner.getGameProfile().name()), "Prompt must contain actual owner name");
            })
            .thenExecute(() -> {
                resetCooldown(mod, owner.getUUID());
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ask Следуй за мной ещё раз");
            })
            .thenWaitUntil(() -> helper.assertTrue(secondRequest.get() != null, "Second turn must send HTTP with the previous reply in history"))
            .thenExecute(() -> {
                var messages = JsonParser.parseString(secondRequest.get()).getAsJsonObject().getAsJsonArray("messages");
                helper.assertTrue(messages.size() == 4, "Second turn must contain system, previous user/assistant and current user");
                helper.assertTrue(messages.get(1).getAsJsonObject().get("content").getAsString().equals("Иди за мной"), "Previous player message retained");
                JsonObject previousAssistant = messages.get(2).getAsJsonObject();
                helper.assertTrue(previousAssistant.get("role").getAsString().equals("assistant"), "Previous reply role retained");
                var previous = OllamaClient.parseReply(previousAssistant.get("content").getAsString());
                helper.assertTrue(previous.action().equals("follow") && previous.say().equals(longSay), "240 HTML-sensitive characters must survive history without breaking the next request");
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
                helper.assertTrue(!savedCompanion(state, owner.getUUID()).get("following").getAsBoolean(), "Manual stay persisted while response is pending");
                releaseSecondReply.countDown();
            })
            .thenWaitUntil(() -> helper.assertTrue(secondReplyAttempted.getCount() == 0, "Delayed follow response must be released"))
            .thenIdle(20)
            .thenExecute(() -> {
                JsonObject saved = savedCompanion(state, owner.getUUID());
                helper.assertTrue(!saved.get("following").getAsBoolean(), "Late follow response must not override manual stay");
                helper.assertTrue(saved.get("entity").getAsString().equals(entityUuid), "Manual command and late reply retain companion UUID");
                helper.assertTrue(requests.get() == 2, "Exactly two AI requests expected");
                cleanup.run();
            })
            .thenSucceed();
    }

    private static JsonObject savedCompanion(Path state, UUID owner) {
        try {
            for (var entry : JsonParser.parseString(Files.readString(state)).getAsJsonArray()) {
                JsonObject companion = entry.getAsJsonObject();
                if (companion.get("owner").getAsString().equals(owner.toString())) return companion;
            }
            throw new IllegalStateException("Missing owner state " + owner);
        } catch (IOException error) { throw new RuntimeException(error); }
    }

    private static void resetCooldown(MarkAIMod mod, UUID owner) {
        try {
            var sessionsField = MarkAIMod.class.getDeclaredField("aiSessions"); sessionsField.setAccessible(true);
            Object session = ((Map<?, ?>) sessionsField.get(mod)).get(owner);
            var nextRequestField = session.getClass().getDeclaredField("nextRequest"); nextRequestField.setAccessible(true);
            nextRequestField.setLong(session, 0);
        } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
    }
}
