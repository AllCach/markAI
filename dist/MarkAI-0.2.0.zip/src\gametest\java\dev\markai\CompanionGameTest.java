package dev.markai;

import dev.markai.mixin.MobAccessor;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;
import java.nio.file.Files;

public final class CompanionGameTest {
    @GameTest(maxTicks = 200)
    public void commandsAndOwnership(GameTestHelper helper) throws Exception {
        for (int x = -5; x < 25; x++) for (int z = -5; z < 25; z++)
            helper.setBlock(new BlockPos(x, 1, z), Blocks.STONE);
        ServerPlayer owner = helper.makeMockServerPlayerInLevel();
        Vec3 position = helper.absoluteVec(new Vec3(2, 2, 2));
        owner.setPos(position.x, position.y, position.z);
        var level = helper.getLevel();
        var server = level.getServer();
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark spawn");
        var chickens = level.getEntitiesOfClass(Chicken.class, owner.getBoundingBox().inflate(5));
        helper.assertTrue(chickens.size() == 1, "Exactly one companion must spawn");
        Chicken mark = chickens.getFirst();
        helper.assertTrue(mark.getHealth() == 4 && mark.getAttribute(Attributes.MAX_HEALTH).getBaseValue() == 4,
            "Companion health must be 4 HP");
        helper.assertTrue(mark.getName().getString().equals("Марк"), "Companion name");
        helper.assertTrue(((MobAccessor) mark).markai$goals().getAvailableGoals().isEmpty(), "Vanilla movement goals removed");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark spawn");
        helper.assertTrue(level.getEntitiesOfClass(Chicken.class, owner.getBoundingBox().inflate(5)).size() == 1,
            "Repeated spawn must not duplicate companion");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
        var state = server.getWorldPath(LevelResource.ROOT).resolve("markai.json");
        String saved = Files.readString(state);
        helper.assertTrue(saved.contains(owner.getUUID().toString()) && saved.contains(mark.getUUID().toString()), "Both UUIDs persisted");
        helper.assertTrue(saved.contains("\"following\": false"), "Stay persisted");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark follow");
        helper.assertTrue(Files.readString(state).contains("\"following\": true"), "Follow persisted");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark status");
        Chicken ordinary = helper.spawn(EntityTypes.CHICKEN, new BlockPos(5, 2, 5));
        helper.assertTrue(!((MobAccessor) ordinary).markai$goals().getAvailableGoals().isEmpty(), "Ordinary chicken goals retained");
        ordinary.discard();
        owner.setPos(position.x + 9, position.y, position.z + 1);
        double initialDistance = mark.distanceTo(owner);
        helper.runAfterDelay(40, () -> {
            helper.assertTrue(mark.distanceTo(owner) < initialDistance - 1, "Companion must move toward owner");
            server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
            helper.runAfterDelay(10, () -> {
                Vec3 stopped = mark.position();
                helper.runAfterDelay(20, () -> {
                    helper.assertTrue(mark.position().distanceTo(stopped) < 0.2, "Stay must stop movement");
                    var enemy = EntityTypes.ZOMBIE.create(level, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
                    enemy.setPos(mark.getX() - 2, mark.getY(), mark.getZ());
                    enemy.setNoAi(true);
                    level.addFreshEntity(enemy);
                    helper.runAfterDelay(30, () -> {
                        helper.assertTrue(mark.distanceTo(enemy) > 3, "Threat must trigger flee even in stay mode: distance="
                            + mark.distanceTo(enemy) + " mark=" + mark.position() + " enemy=" + enemy.position()
                            + " navigationDone=" + mark.getNavigation().isDone() + " enemyAlive=" + enemy.isAlive());
                        enemy.discard();
                        var oldUuid = mark.getUUID();
                        mark.kill(level);
                        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark respawn");
                        var replacements = level.getEntitiesOfClass(Chicken.class, owner.getBoundingBox().inflate(5));
                        helper.assertTrue(replacements.stream().anyMatch(chicken -> chicken.isAlive() && !chicken.getUUID().equals(oldUuid)),
                            "Dead companion must be replaceable");
                        helper.succeed();
                    });
                });
            });
        });
    }
}
