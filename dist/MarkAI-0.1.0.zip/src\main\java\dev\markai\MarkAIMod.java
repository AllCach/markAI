package dev.markai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.markai.brain.MarkBrain;
import dev.markai.mixin.MobAccessor;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;

public final class MarkAIMod implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("markai");
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private final Map<UUID, Companion> companions = new HashMap<>();
    private final Set<UUID> configured = new HashSet<>();
    private MinecraftServer server;
    private int ticks;
    private boolean storageHealthy;

    public static final class Companion {
        UUID owner;
        UUID entity;
        String dimension;
        int chunkX, chunkZ;
        boolean dead;
        boolean following = true;
        transient long nextMessage;
        transient String action = "IDLE";
    }

    @Override public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            companions.clear();
            configured.clear();
            ticks = 0;
            storageHealthy = true;
            Path path = statePath();
            if (Files.exists(path)) {
                try {
                    Companion[] saved = JSON.fromJson(Files.readString(path), Companion[].class);
                    if (saved == null) throw new IOException("Empty state file");
                    for (Companion c : saved) {
                        if (c.owner == null || c.entity == null || c.dimension == null)
                            throw new IOException("Invalid companion state");
                        companions.put(c.owner, c);
                    }
                } catch (Exception e) {
                    storageHealthy = false;
                    LOG.error("Cannot load MarkAI state; spawning disabled to prevent duplicates", e);
                }
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            companions.clear(); configured.clear(); server = null;
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                remember(c, entity, level); configured.remove(c.entity); save();
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                c.dead = true; configured.remove(c.entity); save();
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (++ticks % 10 != 0) return;
            for (Companion c : companions.values()) tick(c);
            if (ticks % 200 == 0) save();
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            var root = Commands.literal("mark");
            for (String name : List.of("spawn", "respawn", "follow", "stay", "status")) {
                root.then(Commands.literal(name).executes(ctx -> command(ctx, name)));
            }
            dispatcher.register(root);
        });
    }

    private int command(CommandContext<CommandSourceStack> context, String command) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer owner = context.getSource().getPlayerOrException();
        if (!storageHealthy) {
            owner.sendSystemMessage(Component.literal("MarkAI: ошибка файла состояния; см. журнал. Создание отключено."));
            return 0;
        }
        Companion c = companions.get(owner.getUUID());
        if (command.equals("spawn") || command.equals("respawn")) {
            if (c != null && !c.dead) {
                // Resolve the saved chunk before deciding anything about an unloaded companion.
                for (ServerLevel level : server.getAllLevels()) {
                    if (level.dimension().identifier().toString().equals(c.dimension))
                        level.getChunk(c.chunkX, c.chunkZ);
                }
                Chicken existing = find(c);
                owner.sendSystemMessage(Component.literal(existing != null
                    ? "Марк уже существует: " + c.entity
                    : "Марк сохранён, но пока не найден. Повторный спавн запрещён: " + c.entity));
                return existing != null ? 1 : 0;
            }
            ServerLevel level = (ServerLevel) owner.level();
            Chicken chicken = EntityTypes.CHICKEN.create(level, EntitySpawnReason.COMMAND);
            if (chicken == null) return 0;
            Vec3 pos = owner.position().add(1, 0, 1);
            chicken.setPos(pos.x, pos.y, pos.z);
            if (!level.noCollision(chicken) || !level.getFluidState(chicken.blockPosition()).isEmpty()) {
                owner.sendSystemMessage(Component.literal("Для Марка нужно свободное сухое место рядом с игроком."));
                return 0;
            }
            chicken.setCustomName(Component.literal("Марк"));
            chicken.setCustomNameVisible(true);
            chicken.getAttribute(Attributes.MAX_HEALTH).setBaseValue(4);
            chicken.setHealth(4);
            chicken.setPersistenceRequired();
            chicken.setAge(0);
            if (!level.addFreshEntity(chicken)) return 0;
            c = new Companion(); c.owner = owner.getUUID(); c.entity = chicken.getUUID();
            remember(c, chicken, level);
            companions.put(c.owner, c);
            configure(chicken);
            save();
            owner.sendSystemMessage(Component.literal("Марк создан. Владелец: " + c.owner));
            return 1;
        }
        if (c == null) {
            owner.sendSystemMessage(Component.literal("Сначала выполните /mark spawn.")); return 0;
        }
        if (command.equals("status")) {
            Chicken chicken = find(c);
            owner.sendSystemMessage(Component.literal("Марк | owner=" + c.owner + " | entity=" + c.entity
                + " | minecraft:chicken | HP=" + (chicken == null ? "?" : chicken.getHealth())
                + "/4 | " + (c.dead ? "DEAD" : chicken == null ? "UNLOADED" : c.action)
                + " | mode=" + (c.following ? "FOLLOW" : "STAY") + " | dimension=" + c.dimension));
        } else {
            c.following = command.equals("follow");
            Chicken chicken = find(c);
            if (chicken != null) { configure(chicken); chicken.getNavigation().stop(); }
            save();
            owner.sendSystemMessage(Component.literal(c.following ? "Марк следует за вами." : "Марк остаётся на месте; при угрозе убегает."));
        }
        return 1;
    }

    private void configure(Chicken chicken) {
        if (configured.add(chicken.getUUID())) {
            ((MobAccessor) chicken).markai$goals().removeAllGoals(goal -> true);
        }
    }

    private Chicken find(Companion c) {
        if (c.dead) return null;
        for (ServerLevel level : server.getAllLevels()) {
            Entity entity = level.getEntity(c.entity);
            if (entity instanceof Chicken chicken && chicken.isAlive()) return chicken;
        }
        return null;
    }

    private void tick(Companion c) {
        Chicken chicken = find(c);
        if (chicken == null) return;
        configure(chicken);
        ServerLevel level = (ServerLevel) chicken.level();
        remember(c, chicken, level);
        ServerPlayer owner = server.getPlayerList().getPlayer(c.owner);
        if (owner == null || !owner.isAlive() || owner.level() != level) {
            chicken.getNavigation().stop(); c.action = "IDLE"; return;
        }
        Entity enemy = level.getEntities(chicken, chicken.getBoundingBox().inflate(12),
                e -> e instanceof Enemy && e.isAlive()).stream()
            .min(Comparator.comparingDouble(chicken::distanceToSqr)).orElse(null);
        MarkBrain.Decision decision = MarkBrain.think(new MarkBrain.WorldState(
            owner.getGameProfile().name(), chicken.distanceTo(owner),
            enemy == null ? Double.POSITIVE_INFINITY : chicken.distanceTo(enemy), (int) chicken.getHealth()));
        String action = decision.action();
        if (!c.following && !action.equals("FLEE")) action = "IDLE";
        switch (action) {
            case "FLEE" -> {
                // Vanilla's escape-position sampler accounts for terrain and reachable ground.
                if (chicken.getNavigation().isDone() || !"FLEE".equals(c.action)) {
                    for (int attempt = 0; attempt < 8; attempt++) {
                        Vec3 target = DefaultRandomPos.getPosAway(chicken, 12, 5, enemy.position());
                        if (target != null && target.distanceToSqr(enemy.position()) > chicken.distanceToSqr(enemy)
                                && chicken.getNavigation().moveTo(target.x, target.y, target.z, 1.5)) break;
                    }
                }
            }
            case "FOLLOW" -> chicken.getNavigation().moveTo(owner, 1.2);
            default -> chicken.getNavigation().stop();
        }
        long now = level.getGameTime();
        if (!action.equals(c.action) && !action.equals("IDLE") && now >= c.nextMessage) {
            owner.sendSystemMessage(Component.literal("<Марк> " + decision.message()));
            c.nextMessage = now + 200;
        }
        c.action = action;
    }

    private void remember(Companion c, Entity entity, ServerLevel level) {
        c.dimension = level.dimension().identifier().toString();
        c.chunkX = entity.chunkPosition().x(); c.chunkZ = entity.chunkPosition().z();
    }

    private Path statePath() { return server.getWorldPath(LevelResource.ROOT).resolve("markai.json"); }

    private void save() {
        if (server == null || !storageHealthy) return;
        try {
            Path target = statePath(), temp = target.resolveSibling("markai.json.tmp");
            Files.writeString(temp, JSON.toJson(companions.values()));
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            storageHealthy = false;
            LOG.error("Cannot save MarkAI state; further commands disabled", e);
        }
    }
}
