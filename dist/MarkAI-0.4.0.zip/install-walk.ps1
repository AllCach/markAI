param([int]$WaitForProcessId = 0)
$ErrorActionPreference = 'Stop'
$installLog = Join-Path $PSScriptRoot 'dist\install-walk.log'
New-Item -ItemType Directory -Path (Split-Path -Parent $installLog) -Force | Out-Null
try {
    if ($WaitForProcessId -gt 0) {
        "Waiting for Minecraft process $WaitForProcessId to exit." | Set-Content -LiteralPath $installLog -Encoding UTF8
        Wait-Process -Id $WaitForProcessId -ErrorAction SilentlyContinue
    }
    $sourceJar = Join-Path $PSScriptRoot 'build\libs\markai-0.4.0.jar'
    if (!(Test-Path -LiteralPath $sourceJar)) { $sourceJar = Join-Path $PSScriptRoot 'markai-0.4.0.jar' }
    $modsDir = Join-Path $env:APPDATA '.minecraft\mods'
    $previousJar = Join-Path $modsDir 'markai-0.3.0.jar'
    $disabledJar = Join-Path $modsDir 'markai-0.3.0.jar.disabled'
    $installedJar = Join-Path $modsDir 'markai-0.4.0.jar'
    $pendingJar = "$installedJar.pending"
    $unexpectedMods = @(Get-ChildItem -LiteralPath $modsDir -Filter 'markai-*.jar' -File |
        Where-Object { $_.Name -notin @('markai-0.3.0.jar', 'markai-0.4.0.jar') })
    if ($unexpectedMods.Count) { throw 'Unexpected active MarkAI version; installation stopped.' }
    if ((Test-Path -LiteralPath $previousJar) -and (Test-Path -LiteralPath $disabledJar)) {
        throw 'Previous backup already exists; installation stopped.'
    }
    Copy-Item -LiteralPath $sourceJar -Destination $pendingJar -Force
    if ((Get-FileHash -LiteralPath $sourceJar).Hash -ne (Get-FileHash -LiteralPath $pendingJar).Hash) {
        throw 'Staged JAR hash mismatch.'
    }
    if (Test-Path -LiteralPath $previousJar) { Move-Item -LiteralPath $previousJar -Destination $disabledJar }
    try { Move-Item -LiteralPath $pendingJar -Destination $installedJar -Force }
    catch {
        if (!(Test-Path -LiteralPath $previousJar) -and (Test-Path -LiteralPath $disabledJar)) {
            Move-Item -LiteralPath $disabledJar -Destination $previousJar
        }
        throw
    }
    if ((Get-FileHash -LiteralPath $sourceJar).Hash -ne (Get-FileHash -LiteralPath $installedJar).Hash) {
        throw 'Installed JAR hash mismatch.'
    }
    'Installed MarkAI 0.4.0: ' + $installedJar | Add-Content -LiteralPath $installLog -Encoding UTF8
} catch {
    $_.Exception.Message | Add-Content -LiteralPath $installLog -Encoding UTF8
    throw
}
