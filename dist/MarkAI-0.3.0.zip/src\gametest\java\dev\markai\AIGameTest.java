package dev.markai;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpServer;
import dev.markai.ai.OllamaClient;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.gametest.framework.GameTestInfo;
import net.minecraft.gametest.framework.GameTestListener;
import net.minecraft.gametest.framework.GameTestRunner;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.vehicle.boat.Boat;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public final class AIGameTest {
    @GameTest(maxTicks = 2000)
    public void validatedReplyChangesOwnerMode(GameTestHelper helper) throws Exception {
        for (int x = 0; x < 7; x++) for (int z = 0; z < 7; z++)
            helper.setBlock(new BlockPos(x, 1, z), Blocks.STONE);
        var owner = helper.makeMockServerPlayerInLevel();
        Vec3 position = helper.absoluteVec(new Vec3(2, 2, 2));
        owner.setPos(position.x, position.y, position.z);
        var server = helper.getLevel().getServer();
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark spawn");
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
        Path state = server.getWorldPath(LevelResource.ROOT).resolve("markai.json");
        String entityUuid = savedCompanion(state, owner.getUUID()).get("entity").getAsString();

        var firstRequest = new AtomicReference<String>();
        var secondRequest = new AtomicReference<String>();
        var thirdRequest = new AtomicReference<String>();
        var expectedObservation = new AtomicReference<JsonObject>();
        var testBoat = new AtomicReference<Boat>();
        var requests = new AtomicInteger();
        var releaseSecondReply = new CountDownLatch(1);
        var secondReplyAttempted = new CountDownLatch(1);
        String longSay = "<".repeat(240);
        HttpServer fake = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var fakeExecutor = Executors.newVirtualThreadPerTaskExecutor();
        fake.setExecutor(fakeExecutor);
        fake.createContext("/api/chat", exchange -> {
            boolean second = false;
            try (exchange) {
                String request = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                int turn = requests.incrementAndGet();
                second = turn == 2;
                if (second) {
                    secondRequest.set(request);
                    try { releaseSecondReply.await(10, TimeUnit.SECONDS); }
                    catch (InterruptedException error) { Thread.currentThread().interrupt(); return; }
                } else if (turn == 1) firstRequest.set(request);
                else thirdRequest.set(request);
                JsonObject message = new JsonObject();
                message.addProperty("role", "assistant");
                message.addProperty("content", new Gson().toJson(new OllamaClient.Reply("follow", turn == 1 ? longSay : turn == 2 ? "Иду!" : "Рад слышать!")));
                JsonObject response = new JsonObject(); response.add("message", message); response.addProperty("done", true);
                byte[] body = response.toString().getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, body.length);
                exchange.getResponseBody().write(body);
            } catch (IOException ignored) {
                // Manual stay cancels the second HTTP request and may close its connection before this write.
            } finally {
                if (second) secondReplyAttempted.countDown();
            }
        });
        fake.start();

        MarkAIMod mod = (MarkAIMod) FabricLoader.getInstance().getEntrypoints("main", ModInitializer.class).stream()
            .filter(value -> value instanceof MarkAIMod).findFirst().orElseThrow();
        var clientField = MarkAIMod.class.getDeclaredField("ollama");
        clientField.setAccessible(true);
        var original = (OllamaClient) clientField.get(mod);
        var client = new OllamaClient("http://127.0.0.1:" + fake.getAddress().getPort(), "qwen3:8b", Duration.ofSeconds(5));
        var cleaned = new AtomicBoolean();
        Runnable cleanup = () -> {
            if (!cleaned.compareAndSet(false, true)) return;
            try {
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ai off");
                clientField.set(mod, original);
            } catch (IllegalAccessException error) { throw new RuntimeException(error); }
            finally {
                releaseSecondReply.countDown();
                client.close(); fake.stop(0); fakeExecutor.shutdownNow();
                if (testBoat.get() != null) { owner.stopRiding(); testBoat.get().discard(); }
            }
        };
        // Restore the shared client even if an asynchronous assertion fails or the test times out.
        var infoField = GameTestHelper.class.getDeclaredField("testInfo");
        infoField.setAccessible(true);
        ((GameTestInfo) infoField.get(helper)).addListener(new GameTestListener() {
            @Override public void testStructureLoaded(GameTestInfo info) {}
            @Override public void testPassed(GameTestInfo info, GameTestRunner runner) { cleanup.run(); }
            @Override public void testFailed(GameTestInfo info, GameTestRunner runner) { cleanup.run(); }
            @Override public void testAddedForRerun(GameTestInfo oldInfo, GameTestInfo newInfo, GameTestRunner runner) { cleanup.run(); }
        });
        clientField.set(mod, client);
        server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ask Иди за мной");
        Path journal = FabricLoader.getInstance().getGameDir().resolve("logs/markai-chat.jsonl");

        helper.startSequence()
            .thenWaitUntil(() -> {
                helper.assertTrue(firstRequest.get() != null, "AI request must be sent asynchronously");
                JsonObject saved = savedCompanion(state, owner.getUUID());
                helper.assertTrue(saved.get("following").getAsBoolean(), "Validated follow reply must change and persist owner mode");
                helper.assertTrue(saved.get("entity").getAsString().equals(entityUuid), "Reply must retain companion UUID");
                helper.assertTrue(firstRequest.get().contains(owner.getGameProfile().name()), "Prompt must contain actual owner name");
            })
            .thenExecute(() -> {
                resetCooldown(mod, owner.getUUID());
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ask Следуй за мной ещё раз");
            })
            .thenWaitUntil(() -> helper.assertTrue(secondRequest.get() != null, "Second turn must send HTTP with the previous reply in history"))
            .thenExecute(() -> {
                var messages = JsonParser.parseString(secondRequest.get()).getAsJsonObject().getAsJsonArray("messages");
                helper.assertTrue(messages.size() == 4, "Second turn must contain combined personality/observation, history and current user");
                helper.assertTrue(messages.get(1).getAsJsonObject().get("content").getAsString().equals("Иди за мной"), "Previous player message retained");
                JsonObject previousAssistant = messages.get(2).getAsJsonObject();
                helper.assertTrue(previousAssistant.get("role").getAsString().equals("assistant"), "Previous reply role retained");
                var previous = OllamaClient.parseReply(previousAssistant.get("content").getAsString());
                helper.assertTrue(previous.action().equals("follow") && previous.say().equals(longSay), "240 HTML-sensitive characters must survive history without breaking the next request");
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark stay");
                helper.assertTrue(!savedCompanion(state, owner.getUUID()).get("following").getAsBoolean(), "Manual stay persisted while response is pending");
                releaseSecondReply.countDown();
            })
            .thenWaitUntil(() -> helper.assertTrue(secondReplyAttempted.getCount() == 0, "Delayed follow response must be released"))
            .thenIdle(20)
            .thenExecute(() -> {
                JsonObject saved = savedCompanion(state, owner.getUUID());
                helper.assertTrue(!saved.get("following").getAsBoolean(), "Late follow response must not override manual stay");
                helper.assertTrue(saved.get("entity").getAsString().equals(entityUuid), "Manual command and late reply retain companion UUID");
                helper.assertTrue(requests.get() == 2, "Exactly two AI requests expected");
                Boat boat = helper.spawn(EntityTypes.OAK_BOAT, new BlockPos(2, 2, 2));
                testBoat.set(boat);
                helper.assertTrue(owner.startRiding(boat), "Owner must actually be riding a boat for the observation check");
                Chicken chicken = (Chicken) helper.getLevel().getEntity(UUID.fromString(entityUuid));
                helper.assertTrue(chicken != null, "Companion must remain loaded");
                JsonObject expected = new JsonObject();
                expected.add("player_position", coordinates(owner.blockPosition()));
                expected.add("companion_position", coordinates(chicken.blockPosition()));
                expected.addProperty("navigation_active", !chicken.getNavigation().isDone());
                expected.addProperty("action", currentCompanion(mod, owner.getUUID()).action);
                expectedObservation.set(expected);
                resetCooldown(mod, owner.getUUID());
                server.getCommands().performPrefixedCommand(owner.createCommandSourceStack(), "mark ask я добрый");
            })
            .thenWaitUntil(() -> helper.assertTrue(thirdRequest.get() != null, "Ordinary conversation must reach Ollama"))
            .thenExecute(() -> {
                JsonObject request = JsonParser.parseString(thirdRequest.get()).getAsJsonObject();
                var actions = request.getAsJsonObject("format").getAsJsonObject("properties").getAsJsonObject("action").getAsJsonArray("enum");
                helper.assertTrue(actions.size() == 1 && actions.get(0).getAsString().equals("say"), "Ordinary conversation must constrain the model schema to say");
                JsonObject context = latestObservation(request);
                JsonObject player = context.getAsJsonObject("player");
                JsonObject companion = context.getAsJsonObject("companion");
                JsonObject movement = companion.getAsJsonObject("movement");
                JsonObject expected = expectedObservation.get();
                helper.assertTrue(player.get("position").equals(expected.get("player_position")), "Snapshot player coordinates must match the actual position at request time");
                helper.assertTrue(companion.get("position").equals(expected.get("companion_position")), "Snapshot companion coordinates must match the actual position at request time");
                helper.assertTrue(player.get("in_boat").getAsBoolean() && player.get("vehicle").getAsString().equals("minecraft:oak_boat"), "Snapshot must report the actual boat");
                helper.assertTrue(!movement.get("following_owner").getAsBoolean() && context.get("mode").getAsString().equals("stay"), "Snapshot must preserve the actual STAY mode");
                helper.assertTrue(movement.get("navigation_active").equals(expected.get("navigation_active")) && movement.get("action").equals(expected.get("action")), "Snapshot movement must match actual navigation and controller action");
            })
            .thenWaitUntil(() -> {
                JsonObject pair = journalPair(journal, entityUuid, "я добрый");
                helper.assertTrue(pair != null, "Journal must contain the ordinary-chat request and response pair");
                JsonObject response = pair.getAsJsonObject("response");
                helper.assertTrue(response.get("status").getAsString().equals("applied"), "Ordinary-chat response must be applied");
                helper.assertTrue(response.getAsJsonObject("proposed").get("action").getAsString().equals("follow"), "Journal must retain the model's proposed follow action");
                helper.assertTrue(response.getAsJsonObject("delivered").get("action").getAsString().equals("say"), "Journal must record the constrained say action actually delivered");
                helper.assertTrue(pair.getAsJsonObject("request").get("context").equals(latestObservation(JsonParser.parseString(thirdRequest.get()).getAsJsonObject())), "Journal must retain the same world observation sent to the model");
            })
            .thenExecute(() -> {
                JsonObject saved = savedCompanion(state, owner.getUUID());
                helper.assertTrue(!saved.get("following").getAsBoolean(), "Model follow proposal during ordinary chat must not change STAY");
                helper.assertTrue(saved.get("entity").getAsString().equals(entityUuid), "Ordinary chat must retain companion UUID");
                helper.assertTrue(requests.get() == 3, "Exactly three AI requests expected");
                cleanup.run();
            })
            .thenSucceed();
    }

    private static JsonObject savedCompanion(Path state, UUID owner) {
        try {
            for (var entry : JsonParser.parseString(Files.readString(state)).getAsJsonArray()) {
                JsonObject companion = entry.getAsJsonObject();
                if (companion.get("owner").getAsString().equals(owner.toString())) return companion;
            }
            throw new IllegalStateException("Missing owner state " + owner);
        } catch (IOException error) { throw new RuntimeException(error); }
    }

    private static void resetCooldown(MarkAIMod mod, UUID owner) {
        try {
            var sessionsField = MarkAIMod.class.getDeclaredField("aiSessions"); sessionsField.setAccessible(true);
            Object session = ((Map<?, ?>) sessionsField.get(mod)).get(owner);
            var nextRequestField = session.getClass().getDeclaredField("nextRequest"); nextRequestField.setAccessible(true);
            nextRequestField.setLong(session, 0);
        } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
    }

    private static MarkAIMod.Companion currentCompanion(MarkAIMod mod, UUID owner) {
        try {
            var companionsField = MarkAIMod.class.getDeclaredField("companions"); companionsField.setAccessible(true);
            return (MarkAIMod.Companion) ((Map<?, ?>) companionsField.get(mod)).get(owner);
        } catch (ReflectiveOperationException error) { throw new RuntimeException(error); }
    }

    private static JsonObject coordinates(BlockPos position) {
        JsonObject result = new JsonObject();
        result.addProperty("x", position.getX()); result.addProperty("y", position.getY()); result.addProperty("z", position.getZ());
        return result;
    }

    private static JsonObject latestObservation(JsonObject request) {
        for (var entry : request.getAsJsonArray("messages")) {
            JsonObject message = entry.getAsJsonObject();
            String content = message.get("content").getAsString();
            int start = content.indexOf("CURRENT_GAME_STATE: ");
            if (message.get("role").getAsString().equals("system") && start >= 0) {
                return JsonParser.parseString(content.substring(start + "CURRENT_GAME_STATE: ".length(),
                    content.indexOf("\nrequested_action=", start))).getAsJsonObject();
            }
        }
        throw new IllegalStateException("Missing fresh observation message");
    }

    private static JsonObject journalPair(Path journal, String entityUuid, String question) {
        try {
            if (!Files.exists(journal)) return null;
            var records = new java.util.ArrayList<JsonObject>();
            for (String line : Files.readAllLines(journal)) {
                try { records.add(JsonParser.parseString(line).getAsJsonObject()); }
                catch (RuntimeException ignored) { /* The asynchronous writer may still be appending this line. */ }
            }
            for (JsonObject request : records) {
                if (!request.get("type").getAsString().equals("request") || !request.get("entity_uuid").getAsString().equals(entityUuid)
                        || !request.get("question").getAsString().equals(question)) continue;
                for (JsonObject response : records) {
                    if (response.get("type").getAsString().equals("response") && response.get("request_id").equals(request.get("request_id"))) {
                        JsonObject pair = new JsonObject(); pair.add("request", request); pair.add("response", response); return pair;
                    }
                }
            }
            return null;
        } catch (IOException error) { throw new RuntimeException(error); }
    }
}
