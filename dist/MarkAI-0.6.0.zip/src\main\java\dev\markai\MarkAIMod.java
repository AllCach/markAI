package dev.markai;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.markai.ai.AIConfig;
import dev.markai.ai.OllamaClient;
import dev.markai.ai.DialogueIntent;
import dev.markai.chat.ChatJournal;
import dev.markai.memory.CompanionMemory;
import dev.markai.training.DogTraining;
import dev.markai.training.DogTraining.Trick;
import dev.markai.inventory.CompanionInventoryHolder;
import dev.markai.mixin.MobAccessor;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.ItemTags;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityReference;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.chicken.Chicken;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import com.mojang.brigadier.arguments.StringArgumentType;

public final class MarkAIMod implements ModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("markai");
    private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson CHAT_JSON = new GsonBuilder().disableHtmlEscaping().create();
    private final Map<UUID, Companion> companions = new HashMap<>();
    private final Set<UUID> configured = new HashSet<>();
    private MinecraftServer server;
    private int ticks;
    private boolean storageHealthy;
    private AIConfig aiConfig;
    private OllamaClient ollama;
    private ChatJournal chatJournal;
    private final Map<UUID, AISession> aiSessions = new HashMap<>();

    private static final class AISession {
        boolean enabled = true;
        long generation;
        long nextRequest;
        long idleUntil, wanderUntil, lookUntil, fleeUntil;
        CompletableFuture<OllamaClient.Reply> pending;
        Runnable cancelTrace;
    }

    public static final class Companion {
        UUID owner;
        UUID entity;
        String dimension;
        int chunkX, chunkZ;
        boolean dead;
        boolean following = true;
        CompanionMemory memory = new CompanionMemory();
        DogTraining training = new DogTraining();
        String lastObservedPlace;
        transient long nextMessage;
        transient long nextLessonAt, nextTrickAt;
        transient TrickTask trick;
        transient boolean ownerUnavailable;
        transient String action = "IDLE";
    }

    private static final class TrickTask {
        final Trick kind;
        final long deadline;
        final UUID item;
        boolean carrying;
        TrickTask(Trick kind, long deadline, UUID item) {
            this.kind = kind; this.deadline = deadline; this.item = item;
        }
    }

    @Override public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            companions.clear();
            configured.clear();
            ticks = 0;
            aiSessions.clear();
            chatJournal = new ChatJournal(FabricLoader.getInstance().getGameDir().resolve("logs"));
            try {
                aiConfig = AIConfig.load(FabricLoader.getInstance().getConfigDir().resolve("markai.json"));
                ollama = new OllamaClient(aiConfig.ollamaUrl, aiConfig.ollamaModel, Duration.ofSeconds(aiConfig.timeoutSeconds), aiConfig.thinking);
            } catch (Exception e) {
                ollama = null;
                LOG.error("Cannot initialize local AI; deterministic companion behavior remains available", e);
            }
            storageHealthy = true;
            Path path = statePath();
            if (Files.exists(path)) {
                try {
                    Companion[] saved = JSON.fromJson(Files.readString(path), Companion[].class);
                    if (saved == null) throw new IOException("Empty state file");
                    for (Companion c : saved) {
                        if (c.owner == null || c.entity == null || c.dimension == null)
                            throw new IOException("Invalid companion state");
                        if (c.memory == null) c.memory = new CompanionMemory();
                        if (c.training == null) c.training = new DogTraining();
                        c.memory.normalize(); c.training.normalize();
                        companions.put(c.owner, c);
                    }
                } catch (Exception e) {
                    storageHealthy = false;
                    LOG.error("Cannot load MarkAI state; spawning disabled to prevent duplicates", e);
                }
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            for (Companion c : companions.values()) cancelTrick(c);
            save();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> {
            for (AISession session : aiSessions.values()) invalidate(session);
            aiSessions.clear();
            if (ollama != null) { ollama.close(); ollama = null; }
            if (chatJournal != null) { chatJournal.close(); chatJournal = null; }
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            companions.clear(); configured.clear(); server = null;
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            AISession ownerSession = aiSessions.get(entity.getUUID());
            if (ownerSession != null) invalidate(ownerSession);
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                cancelTrick(c);
                remember(c, entity, level); configured.remove(c.entity); save();
                AISession session = aiSessions.get(c.owner);
                if (session != null) invalidate(session);
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            AISession ownerSession = aiSessions.get(entity.getUUID());
            if (ownerSession != null) invalidate(ownerSession);
            for (Companion c : companions.values()) if (entity.getUUID().equals(c.entity)) {
                c.dead = true; configured.remove(c.entity); save();
                AISession session = aiSessions.get(c.owner);
                if (session != null) invalidate(session);
            }
            if (entity instanceof Enemy) for (Companion c : companions.values()) {
                if (source.getEntity() != null && c.entity.equals(source.getEntity().getUUID())) {
                    c.memory.rememberEvent("won:" + entity.getType().getDescriptionId(),
                        "Я победил противника: " + entity.getType().getDescription().getString() + ".", entity.level().getGameTime());
                    save();
                }
            }
        });
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damage, blocked) -> {
            if (blocked || damage <= 0) return;
            for (Companion c : companions.values()) {
                if (entity.getUUID().equals(c.entity)) c.memory.rememberEvent("hurt",
                    "Я получил ранение. После удара у меня было " + (int) entity.getHealth() + " HP.", entity.level().getGameTime());
                else if (entity.getUUID().equals(c.owner) && source.getEntity() != null
                        && entity.level() instanceof ServerLevel level && level.getEntity(c.entity) instanceof Wolf witness
                        && witness.distanceTo(entity) < 24)
                    c.memory.rememberEvent("owner_hurt", "На хозяина напал " + source.getEntity().getType().getDescription().getString() + ".", entity.level().getGameTime());
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(s -> {
            if (++ticks % 10 != 0) return;
            for (Companion c : companions.values()) tick(c);
            if (ticks % 200 == 0) save();
        });
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.signedContent().strip();
            String lower = text.toLowerCase(Locale.ROOT);
            for (String prefix : List.of("walk,", "walk:", "волк,", "волк:", "марк,", "марк:", "mark,", "mark:")) {
                if (lower.startsWith(prefix)) {
                    ask(sender, text.substring(prefix.length()).strip());
                    break;
                }
            }
        });
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!(entity instanceof Wolf wolf) || hand != InteractionHand.MAIN_HAND || !player.isShiftKeyDown()
                    || !((CompanionInventoryHolder) wolf).markai$isCompanion() || player.isSpectator())
                return InteractionResult.PASS;
            // The synced marker lets the client suppress feeding/sitting before the menu arrives.
            if (level.isClientSide()) return InteractionResult.CONSUME;
            if (!(player instanceof ServerPlayer owner)) return InteractionResult.FAIL;
            Companion c = companions.get(owner.getUUID());
            if (!storageHealthy || c == null || c.dead || !c.entity.equals(wolf.getUUID()) || !wolf.isAlive()
                    || !wolf.isOwnedBy(owner) || owner.level() != wolf.level() || owner.distanceToSqr(wolf) > 64) {
                owner.sendSystemMessage(Component.literal("Инвентарь walk доступен только его хозяину рядом с волком."));
                return InteractionResult.FAIL;
            }
            cancelTrick(c);
            var inventory = ((CompanionInventoryHolder) wolf).markai$inventory();
            owner.openMenu(new SimpleMenuProvider((id, playerInventory, menuOwner) ->
                new ChestMenu(MenuType.GENERIC_9x1, id, playerInventory, inventory, 1),
                Component.literal("walk — инвентарь")));
            return InteractionResult.CONSUME;
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            var root = Commands.literal("mark").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "/walk spawn | follow | stay | status | skills | train <голос/ко мне/принеси> | bark | come | fetch | forget | ask <текст> | ai on/off"), false);
                return 1;
            });
            for (String name : List.of("spawn", "respawn", "follow", "stay", "status", "skills", "forget", "bark", "come", "fetch")) {
                root.then(Commands.literal(name).executes(ctx -> command(ctx, name)));
            }
            root.then(Commands.literal("train").then(Commands.argument("trick", StringArgumentType.greedyString())
                .executes(ctx -> train(ctx.getSource().getPlayerOrException(), StringArgumentType.getString(ctx, "trick")))));
            root.then(Commands.literal("ask").then(Commands.argument("message", StringArgumentType.greedyString())
                .executes(ctx -> ask(ctx.getSource().getPlayerOrException(), StringArgumentType.getString(ctx, "message")))));
            var ai = Commands.literal("ai").executes(ctx -> aiCommand(ctx.getSource().getPlayerOrException(), "status"));
            for (String mode : List.of("on", "off", "status"))
                ai.then(Commands.literal(mode).executes(ctx -> aiCommand(ctx.getSource().getPlayerOrException(), mode)));
            root.then(ai);
            var registered = dispatcher.register(root);
            dispatcher.register(Commands.literal("walk").executes(registered.getCommand()).redirect(registered));
        });
    }

    private int command(CommandContext<CommandSourceStack> context, String command) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer owner = context.getSource().getPlayerOrException();
        if (!storageHealthy) {
            owner.sendSystemMessage(Component.literal("MarkAI: ошибка файла состояния; см. журнал. Создание отключено."));
            return 0;
        }
        Companion c = companions.get(owner.getUUID());
        if (command.equals("spawn") || command.equals("respawn")) {
            if (c != null && !c.dead) {
                // Resolve the saved chunk before deciding anything about an unloaded companion.
                for (ServerLevel level : server.getAllLevels()) {
                    if (level.dimension().identifier().toString().equals(c.dimension))
                        level.getChunk(c.chunkX, c.chunkZ);
                }
                Wolf existing = find(c);
                owner.sendSystemMessage(Component.literal(existing != null
                    ? "walk уже существует: " + c.entity
                    : "walk сохранён, но пока не найден. Повторный спавн запрещён: " + c.entity));
                return existing != null ? 1 : 0;
            }
            ServerLevel level = (ServerLevel) owner.level();
            Wolf wolf = EntityTypes.WOLF.create(level, EntitySpawnReason.COMMAND);
            if (wolf == null) return 0;
            Vec3 pos = owner.position().add(1, 0, 1);
            wolf.setPos(pos.x, pos.y, pos.z);
            if (!level.noCollision(wolf) || !level.getFluidState(wolf.blockPosition()).isEmpty()) {
                owner.sendSystemMessage(Component.literal("Для walk нужно свободное сухое место рядом с игроком."));
                return 0;
            }
            wolf.setCustomName(Component.literal("walk"));
            wolf.setCustomNameVisible(true);
            wolf.tame(owner);
            wolf.setHealth(wolf.getMaxHealth());
            wolf.setPersistenceRequired();
            wolf.setAge(0);
            if (!level.addFreshEntity(wolf)) return 0;
            c = new Companion(); c.owner = owner.getUUID(); c.entity = wolf.getUUID();
            remember(c, wolf, level);
            companions.put(c.owner, c);
            AISession previous = aiSessions.remove(c.owner);
            if (previous != null) invalidate(previous);
            configure(c, wolf);
            save();
            owner.sendSystemMessage(Component.literal("walk создан. Владелец: " + c.owner));
            return 1;
        }
        if (c == null) {
            owner.sendSystemMessage(Component.literal("Сначала выполните /mark spawn.")); return 0;
        }
        if (command.equals("skills")) {
            owner.sendSystemMessage(Component.literal(c.training.status()));
        } else if (command.equals("forget")) {
            invalidate(aiSessions.computeIfAbsent(c.owner, key -> new AISession()));
            c.memory.clear(); save();
            owner.sendSystemMessage(Component.literal("walk: память разговоров и приключений очищена. Навыки сохранены."));
        } else if (List.of("bark", "come", "fetch").contains(command)) {
            return performTrick(owner, Trick.valueOf(command.toUpperCase(Locale.ROOT)));
        } else if (command.equals("status")) {
            Wolf wolf = find(c);
            owner.sendSystemMessage(Component.literal("walk | owner=" + c.owner + " | entity=" + c.entity
                + " | minecraft:wolf | HP=" + (wolf == null ? "?" : wolf.getHealth())
                + "/" + (wolf == null ? "?" : wolf.getMaxHealth()) + " | " + (c.dead ? "DEAD" : wolf == null ? "UNLOADED" : c.action)
                + " | mode=" + (c.following ? "FOLLOW" : "STAY") + " | dimension=" + c.dimension));
            owner.sendSystemMessage(Component.literal(c.training.status()));
        } else {
            cancelTrick(c);
            invalidate(aiSessions.computeIfAbsent(c.owner, key -> new AISession()));
            c.following = command.equals("follow");
            Wolf wolf = find(c);
            if (wolf != null) {
                configure(c, wolf);
                wolf.setOrderedToSit(!c.following);
                wolf.getNavigation().stop();
                if (!c.following) wolf.setTarget(null);
            }
            save();
            owner.sendSystemMessage(Component.literal(c.following ? "walk следует за вами." : "walk сидит и ждёт."));
        }
        return 1;
    }

    private void configure(Companion c, Wolf wolf) {
        if (configured.add(wolf.getUUID())) {
            ((CompanionInventoryHolder) wolf).markai$setCompanion(true);
            if (!wolf.isTame()) wolf.setTame(true, true);
            wolf.setOwnerReference(EntityReference.of(c.owner));
            wolf.setCustomName(Component.literal("walk"));
            wolf.setCustomNameVisible(true);
            wolf.setPersistenceRequired();
            var goals = ((MobAccessor) wolf).markai$goals();
            // Keep the wolf's melee, owner defense, swimming, sitting and natural sounds.
            goals.removeAllGoals(goal -> goal instanceof FollowOwnerGoal);
            goals.addGoal(6, new FollowOwnerGoal(wolf, 1.0, 4.0F, 2.0F));
            goals.addGoal(1, new CompanionIntentGoal(c, wolf));
            goals.addGoal(3, new DogTrickGoal(c, wolf));
            // A carried item is an ordinary persistent passenger, never a copied inventory item.
            for (Entity passenger : List.copyOf(wolf.getPassengers()))
                if (passenger instanceof ItemEntity item) { item.stopRiding(); item.setDefaultPickUpDelay(); }
            wolf.setOrderedToSit(!c.following);
        }
    }

    private Wolf find(Companion c) {
        if (c.dead) return null;
        for (ServerLevel level : server.getAllLevels()) {
            Entity entity = level.getEntity(c.entity);
            if (entity instanceof Wolf wolf && wolf.isAlive()) return wolf;
            if (entity instanceof Chicken chicken && chicken.isAlive() && storageHealthy)
                return migrate(c, chicken, level);
        }
        return null;
    }

    private Wolf migrate(Companion c, Chicken chicken, ServerLevel level) {
        Wolf wolf = EntityTypes.WOLF.create(level, EntitySpawnReason.CONVERSION);
        if (wolf == null) return null;
        wolf.setPos(chicken.getX(), chicken.getY(), chicken.getZ());
        // The wolf is larger: wait until there is room instead of suffocating on conversion.
        if (!level.noCollision(wolf)) return null;
        wolf.setTame(true, true);
        wolf.setOwnerReference(EntityReference.of(c.owner));
        wolf.setHealth(wolf.getMaxHealth());
        configure(c, wolf);
        if (!level.addFreshEntity(wolf)) { configured.remove(wolf.getUUID()); return null; }
        UUID previousUuid = c.entity;
        c.entity = wolf.getUUID();
        remember(c, wolf, level);
        save();
        if (!storageHealthy) {
            c.entity = previousUuid;
            configured.remove(wolf.getUUID());
            wolf.discard();
            return null;
        }
        AISession session = aiSessions.remove(c.owner);
        if (session != null) invalidate(session);
        configured.remove(previousUuid);
        chicken.discard();
        LOG.info("Converted companion {} to tamed wolf {} for owner {}", previousUuid, c.entity, c.owner);
        return wolf;
    }

    private void tick(Companion c) {
        Wolf wolf = find(c);
        if (wolf == null) return;
        configure(c, wolf);
        ServerLevel level = (ServerLevel) wolf.level();
        remember(c, wolf, level);
        ServerPlayer owner = server.getPlayerList().getPlayer(c.owner);
        if (owner == null || !owner.isAlive() || owner.level() != level) {
            cancelTrick(c);
            c.ownerUnavailable = true;
            wolf.setOrderedToSit(true);
            wolf.setTarget(null);
            wolf.getNavigation().stop(); c.action = "IDLE"; return;
        }
        if (c.ownerUnavailable) {
            c.ownerUnavailable = false;
            wolf.setOrderedToSit(!c.following);
        } else if (c.trick == null && c.following == wolf.isOrderedToSit()) {
            // Respect the owner's normal right-click and the wolf standing up to retaliate.
            c.following = !wolf.isOrderedToSit();
            AISession previous = aiSessions.get(c.owner);
            if (previous != null) invalidate(previous);
            save();
        }
        long now = level.getGameTime();
        AISession session = aiSessions.get(c.owner);
        String intent = temporaryIntent(session, now);
        c.action = c.trick != null ? c.trick.kind.name()
            : intent != null ? intent
            : wolf.getTarget() != null && wolf.getTarget().isAlive() ? "ATTACK"
            : !c.following ? "STAY" : wolf.distanceTo(owner) > 4 ? "FOLLOW" : "IDLE";
        // Vanilla goals own navigation, including melee and defense of the tamed owner.
        if (wolf.distanceTo(owner) < 24) {
            String biome = level.getBiome(wolf.blockPosition()).unwrapKey().map(k -> k.identifier().toString()).orElse("unknown");
            String place = c.dimension + "/" + biome;
            if (!place.equals(c.lastObservedPlace)) {
                c.lastObservedPlace = place;
                c.memory.rememberEvent("visit:" + place, "Мы с хозяином были в биоме " + biome + ", измерение " + c.dimension + ".", now);
            }
        }
    }

    private static String temporaryIntent(AISession session, long now) {
        if (session == null) return null;
        if (session.fleeUntil > now) return "FLEE";
        if (session.idleUntil > now || session.lookUntil > now) return "IDLE";
        return session.wanderUntil > now ? "WANDER" : null;
    }

    private final class CompanionIntentGoal extends Goal {
        private final Companion companion;
        private final Wolf wolf;

        CompanionIntentGoal(Companion companion, Wolf wolf) {
            this.companion = companion;
            this.wolf = wolf;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override public boolean canUse() {
            ServerPlayer owner = server == null ? null : server.getPlayerList().getPlayer(companion.owner);
            return owner != null && owner.isAlive() && owner.level() == wolf.level()
                && temporaryIntent(aiSessions.get(companion.owner), wolf.level().getGameTime()) != null;
        }

        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void start() { wolf.setInSittingPose(false); wolf.getNavigation().stop(); }
        @Override public void stop() { wolf.getNavigation().stop(); }

        @Override public void tick() {
            AISession session = aiSessions.get(companion.owner);
            long now = wolf.level().getGameTime();
            String action = temporaryIntent(session, now);
            if (action == null) return;
            if (action.equals("FLEE")) {
                Entity enemy = wolf.level().getEntities(wolf, wolf.getBoundingBox().inflate(12),
                        e -> e instanceof Enemy && e.isAlive()).stream()
                    .min(Comparator.comparingDouble(wolf::distanceToSqr)).orElse(null);
                if (enemy != null && wolf.getNavigation().isDone()) {
                    Vec3 target = DefaultRandomPos.getPosAway(wolf, 12, 5, enemy.position());
                    if (target != null) wolf.getNavigation().moveTo(target.x, target.y, target.z, 1.5);
                }
            } else if (action.equals("WANDER")) {
                if (wolf.getNavigation().isDone()) {
                    Vec3 target = DefaultRandomPos.getPos(wolf, 5, 3);
                    if (target != null) wolf.getNavigation().moveTo(target.x, target.y, target.z, 1.0);
                }
            } else wolf.getNavigation().stop();
            ServerPlayer owner = server.getPlayerList().getPlayer(companion.owner);
            if (owner != null && session.lookUntil > now) wolf.getLookControl().setLookAt(owner, 30, 30);
        }
    }

    private int train(ServerPlayer owner, String name) {
        Companion c = companions.get(owner.getUUID());
        Wolf wolf = c == null ? null : find(c);
        Trick trick = Trick.parse(name);
        if (!storageHealthy || wolf == null || !owner.isAlive() || owner.level() != wolf.level()) {
            owner.sendSystemMessage(Component.literal("Для обучения нужен ваш живой walk рядом.")); return 0;
        }
        if (trick == null) {
            owner.sendSystemMessage(Component.literal("Обучение: /walk train голос | ко мне | принеси")); return 0;
        }
        if (wolf.distanceTo(owner) > 4 || wolf.getTarget() != null || c.trick != null) {
            owner.sendSystemMessage(Component.literal("Подойдите к walk. Тренироваться можно, когда он свободен и бой закончен.")); return 0;
        }
        if (!c.training.canTrain(trick)) {
            owner.sendSystemMessage(Component.literal(c.training.knows(trick) ? "walk уже освоил «" + trick.title + "»."
                : "Для «" + trick.title + "» нужен уровень " + trick.requiredLevel + ".")); return 0;
        }
        long now = wolf.level().getGameTime();
        if (now < c.nextLessonAt) {
            owner.sendSystemMessage(Component.literal("Дайте walk пару секунд между уроками.")); return 0;
        }
        var treat = owner.getMainHandItem();
        if (!treat.is(ItemTags.WOLF_FOOD)) {
            owner.sendSystemMessage(Component.literal("Возьмите в основную руку мясное лакомство, например жареную говядину.")); return 0;
        }
        c.training.train(trick);
        if (!owner.getAbilities().instabuild) treat.shrink(1);
        c.nextLessonAt = now + 40;
        wolf.getLookControl().setLookAt(owner, 30, 30);
        ((ServerLevel) wolf.level()).sendParticles(ParticleTypes.HEART, wolf.getX(), wolf.getY() + 0.8, wolf.getZ(), 3, 0.2, 0.2, 0.2, 0.01);
        if (trick == Trick.BARK) bark(wolf);
        if (c.training.knows(trick)) {
            c.memory.rememberEvent("learned:" + trick, "Хозяин научил меня команде «" + trick.title + "».", now);
            owner.sendSystemMessage(Component.literal("walk освоил «" + trick.title + "»! " + c.training.status()));
        } else owner.sendSystemMessage(Component.literal("Урок «" + trick.title + "»: " + c.training.progress(trick) + "/3. " + c.training.status()));
        save();
        return 1;
    }

    private static void bark(Wolf wolf) {
        wolf.playSound(wolf.get(DataComponents.WOLF_SOUND_VARIANT).value().adultSounds().ambientSound().value(), 0.8F, 1.0F);
    }

    private int performTrick(ServerPlayer owner, Trick trick) {
        Companion c = companions.get(owner.getUUID());
        Wolf wolf = c == null ? null : find(c);
        if (!storageHealthy || wolf == null || !owner.isAlive() || owner.level() != wolf.level() || wolf.distanceTo(owner) > 32) {
            owner.sendSystemMessage(Component.literal("walk должен быть загружен и находиться поблизости.")); return 0;
        }
        if (!c.training.knows(trick)) {
            owner.sendSystemMessage(Component.literal("walk ещё не знает «" + trick.title + "». Обучение: /walk train " + trick.title)); return 0;
        }
        long now = wolf.level().getGameTime();
        if (now < c.nextTrickAt || (wolf.getTarget() != null && trick != Trick.BARK)) {
            owner.sendSystemMessage(Component.literal("walk занят. Повторите команду чуть позже.")); return 0;
        }
        ItemEntity item = null;
        if (trick == Trick.FETCH) {
            item = wolf.level().getEntitiesOfClass(ItemEntity.class, wolf.getBoundingBox().inflate(c.training.fetchRange()),
                e -> e.isAlive() && !e.isPassenger() && !e.getItem().isEmpty() && e.getOwner() == owner)
                .stream().min(Comparator.comparingDouble(wolf::distanceToSqr)).orElse(null);
            if (item == null) {
                owner.sendSystemMessage(Component.literal("Бросьте предмет клавишей Q неподалёку от walk, затем скажите «принеси».")); return 0;
            }
        }
        cancelTrick(c);
        invalidate(aiSessions.computeIfAbsent(c.owner, key -> new AISession()));
        c.nextTrickAt = now + 40;
        if (trick == Trick.BARK) {
            bark(wolf);
            completeTrick(c, wolf, trick);
        } else {
            c.trick = new TrickTask(trick, now + 600, item == null ? null : item.getUUID());
            wolf.setOrderedToSit(false);
            wolf.setInSittingPose(false);
            wolf.getNavigation().stop();
            owner.sendSystemMessage(Component.literal(trick == Trick.COME ? "walk бежит к вам." : "walk идёт за предметом."));
        }
        return 1;
    }

    private void completeTrick(Companion c, Wolf wolf, Trick trick) {
        c.training.completed(wolf.level().getGameTime());
        c.memory.rememberEvent("trick:" + trick, "Я выполнил команду хозяина «" + trick.title + "».", wolf.level().getGameTime());
        c.trick = null;
        wolf.getNavigation().stop();
        wolf.setOrderedToSit(!c.following);
        save();
    }

    private void cancelTrick(Companion c) {
        TrickTask task = c.trick;
        c.trick = null;
        if (task == null) return;
        Wolf wolf = find(c);
        if (wolf == null) return;
        if (task.item != null && wolf.level() instanceof ServerLevel level && level.getEntity(task.item) instanceof ItemEntity item
                && item.getVehicle() == wolf) {
            item.stopRiding(); item.setDefaultPickUpDelay();
        }
        wolf.getNavigation().stop();
        wolf.setOrderedToSit(wolf.getTarget() == null && !c.following);
    }

    private final class DogTrickGoal extends Goal {
        private final Companion companion;
        private final Wolf wolf;
        DogTrickGoal(Companion companion, Wolf wolf) {
            this.companion = companion; this.wolf = wolf;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }
        @Override public boolean canUse() {
            ServerPlayer owner = server == null ? null : server.getPlayerList().getPlayer(companion.owner);
            return companion.trick != null && wolf.level().getGameTime() < companion.trick.deadline
                && wolf.getTarget() == null && owner != null && owner.isAlive() && owner.level() == wolf.level();
        }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void stop() { cancelTrick(companion); }
        private void approach(Entity target, double speed) {
            // Pathfinding may stop at a reachable nearby node. Finish the short visible approach
            // through normal movement/collision instead of pretending the item was reached.
            if (wolf.distanceTo(target) < 5 && wolf.hasLineOfSight(target)) {
                wolf.getNavigation().stop();
                wolf.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), speed);
            } else wolf.getNavigation().moveTo(wolf.getNavigation().createPath(target.blockPosition(), 0), speed);
        }
        @Override public void tick() {
            TrickTask task = companion.trick;
            if (task == null) return;
            ServerPlayer owner = server.getPlayerList().getPlayer(companion.owner);
            if (owner == null) return;
            if (task.kind == Trick.COME) {
                if (wolf.distanceTo(owner) < 1.8) {
                    completeTrick(companion, wolf, task.kind);
                    owner.sendSystemMessage(Component.literal("walk подошёл к вам."));
                } else approach(owner, 1.1 + companion.training.level() * 0.02);
                return;
            }
            Entity entity = ((ServerLevel) wolf.level()).getEntity(task.item);
            if (!(entity instanceof ItemEntity item) || !item.isAlive()) { cancelTrick(companion); return; }
            if (!task.carrying) {
                if (wolf.distanceTo(item) < 1.6) {
                    if (item.hasPickUpDelay()) return;
                    if (!item.startRiding(wolf, true, false)) { cancelTrick(companion); return; }
                    item.setTarget(companion.owner);
                    task.carrying = true;
                    wolf.getNavigation().stop();
                } else approach(item, 1.1);
            } else {
                item.setPickUpDelay(10);
                if (wolf.distanceTo(owner) < 2.0) {
                    item.stopRiding();
                    var remaining = item.getItem().copy();
                    owner.getInventory().add(remaining);
                    if (remaining.isEmpty()) item.discard();
                    else {
                        item.setItem(remaining); item.setPos(owner.getX(), owner.getY(), owner.getZ());
                        item.setNoPickUpDelay();
                    }
                    completeTrick(companion, wolf, task.kind);
                    owner.sendSystemMessage(Component.literal("walk принёс ваш предмет."));
                } else approach(owner, 1.1 + companion.training.level() * 0.02);
            }
        }
    }

    private int aiCommand(ServerPlayer owner, String mode) {
        AISession session = aiSessions.computeIfAbsent(owner.getUUID(), key -> new AISession());
        if (!mode.equals("status")) {
            invalidate(session);
            session.enabled = mode.equals("on");
        }
        owner.sendSystemMessage(Component.literal("walk: ИИ " + (session.enabled ? "включён" : "выключен")
            + ", модель=" + (aiConfig == null ? "ошибка конфига" : aiConfig.ollamaModel)
            + (ollama == null ? ", клиент недоступен; см. журнал" : "")
            + (session.pending == null ? "" : ", ожидаю ответ")
            + ". Обращение: /mark ask <текст> или walk, <текст>."));
        return 1;
    }

    private static void invalidate(AISession session) {
        session.generation++;
        if (session.cancelTrace != null) {
            session.cancelTrace.run(); session.cancelTrace = null;
        }
        if (session.pending != null) { session.pending.cancel(true); session.pending = null; }
        session.idleUntil = session.wanderUntil = session.lookUntil = session.fleeUntil = 0;
    }

    private int ask(ServerPlayer owner, String message) {
        if (!storageHealthy) {
            owner.sendSystemMessage(Component.literal("MarkAI: ошибка файла состояния; см. журнал.")); return 0;
        }
        Companion c = companions.get(owner.getUUID());
        Wolf wolf = c == null ? null : find(c);
        if (wolf == null || !owner.isAlive() || wolf.level() != owner.level()) {
            owner.sendSystemMessage(Component.literal("walk должен быть жив и загружен в вашем измерении. Проверьте /mark status."));
            return 0;
        }
        Trick requestedTrick = Trick.parse(message);
        if (requestedTrick != null) return performTrick(owner, requestedTrick);
        String lowerMessage = message.toLowerCase(Locale.ROOT);
        for (String prefix : List.of("учи ", "учим ", "научись ", "тренируй ")) {
            if (lowerMessage.startsWith(prefix)) return train(owner, message.substring(prefix.length()));
        }
        AISession session = aiSessions.computeIfAbsent(c.owner, key -> new AISession());
        if (!session.enabled || ollama == null) {
            owner.sendSystemMessage(Component.literal("ИИ недоступен. /mark ai on; настройки: config/markai.json.")); return 0;
        }
        if (message.isBlank() || message.length() > 512) {
            owner.sendSystemMessage(Component.literal("Сообщение для walk: от 1 до 512 символов.")); return 0;
        }
        long nowMillis = System.currentTimeMillis();
        if (session.pending != null || aiSessions.values().stream().anyMatch(s -> s.pending != null)
                || nowMillis < session.nextRequest) {
            owner.sendSystemMessage(Component.literal("walk ещё думает. Подождите немного.")); return 0;
        }
        session.nextRequest = nowMillis + aiConfig.requestCooldownSeconds * 1000L;
        MinecraftServer requestServer = server;
        UUID entityUuid = c.entity;
        var requestLevel = wolf.level();
        long generation = ++session.generation;
        String context = snapshot(c, wolf, owner, message);
        ChatJournal journal = chatJournal;
        String requestId = journal.begin(c.owner, c.entity, owner.getGameProfile().name(), message, context);
        session.cancelTrace = () -> journal.finish(requestId, "cancelled", null, null, null);
        var pending = ollama.ask(context, message, c.memory.history());
        session.pending = pending;
        owner.sendSystemMessage(Component.literal("walk думает…"));
        pending.whenComplete((reply, error) -> {
            if (pending.isCancelled()) {
                journal.finish(requestId, "cancelled", reply, null, null); return;
            }
            try {
                requestServer.execute(() -> {
                    if (server != requestServer || aiSessions.get(c.owner) != session || session.generation != generation) {
                        journal.finish(requestId, "discarded", reply, null, "Session changed"); return;
                    }
                    session.pending = null;
                    session.cancelTrace = null;
                    if (!session.enabled || companions.get(c.owner) != c || !entityUuid.equals(c.entity)) {
                        journal.finish(requestId, "discarded", reply, null, "Companion changed"); return;
                    }
                    ServerPlayer currentOwner = requestServer.getPlayerList().getPlayer(c.owner);
                    Wolf current = find(c);
                    if (currentOwner != owner || !currentOwner.isAlive() || current == null
                            || current.level() != requestLevel || current.level() != currentOwner.level()) {
                        journal.finish(requestId, "discarded", reply, null, "Owner or world changed"); return;
                    }
                    if (error != null) {
                        LOG.warn("Local AI request failed: {}", error.toString());
                        String fallback = "Сейчас не могу ответить. Проверь Ollama; я продолжу действовать по обстановке.";
                        currentOwner.sendSystemMessage(Component.literal("<walk> " + fallback));
                        journal.finish(requestId, "failed", null, new OllamaClient.Reply("say", fallback), error.toString());
                        return;
                    }
                    // Conversation cannot change movement just because the model selected an action.
                    var delivered = new OllamaClient.Reply(DialogueIntent.requestedAction(message), reply.say());
                    applyReply(c, current, currentOwner, session, delivered);
                    journal.finish(requestId, "applied", reply, delivered, null);
                    c.memory.rememberExchange(message, delivered, current.level().getGameTime());
                    save();
                });
            } catch (java.util.concurrent.RejectedExecutionException ignored) {
                journal.finish(requestId, "discarded", reply, null, "Server stopped");
            }
        });
        return 1;
    }

    private String snapshot(Companion c, Wolf wolf, ServerPlayer owner, String question) {
        var level = (ServerLevel) wolf.level();
        var hostiles = level.getEntities(wolf, wolf.getBoundingBox().inflate(12), e -> e instanceof Enemy && e.isAlive())
            .stream().sorted(Comparator.comparingDouble(wolf::distanceToSqr)).limit(5)
            .map(e -> Map.of("type", BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString(),
                "distance_blocks", wolf.distanceTo(e), "visible", wolf.hasLineOfSight(e))).toList();
        var nearby = level.getEntities(wolf, wolf.getBoundingBox().inflate(12),
                e -> e instanceof net.minecraft.world.entity.Mob && !(e instanceof Enemy) && e.isAlive())
            .stream().sorted(Comparator.comparingDouble(wolf::distanceToSqr)).limit(6)
            .map(e -> Map.of("type", BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString(),
                "distance_blocks", wolf.distanceTo(e), "visible", wolf.hasLineOfSight(e))).toList();
        var vehicle = owner.getVehicle();
        String vehicleType = vehicle == null ? "none" : BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType()).toString();
        return CHAT_JSON.toJson(Map.of(
            "companion", Map.of("name", "walk", "type", "minecraft:wolf", "health", wolf.getHealth(), "max_health", wolf.getMaxHealth(),
                "tamed", wolf.isTame(), "can_attack", true, "owner_uuid", c.owner.toString(),
                "position", position(wolf), "in_water", wolf.isInWater(),
                "movement", Map.of("action", c.action == null ? "IDLE" : c.action,
                    "navigation_active", !wolf.getNavigation().isDone(), "following_owner", c.following)),
            "player", Map.of("name", owner.getGameProfile().name(), "distance_blocks", wolf.distanceTo(owner),
                "position", position(owner), "in_water", owner.isInWater(), "in_boat", vehicleType.contains("boat"),
                "vehicle", vehicleType, "held_item", BuiltInRegistries.ITEM.getKey(owner.getMainHandItem().getItem()).toString()),
            "danger_now", hostiles.stream().anyMatch(h -> ((Number) h.get("distance_blocks")).doubleValue() < 6),
            "nearby_hostiles", hostiles, "nearby_entities", nearby, "mode", c.following ? "follow" : "stay",
            "dimension", c.dimension, "memory", c.memory.context(question), "training", c.training.context()));
    }

    private static Map<String, Integer> position(Entity entity) {
        var pos = entity.blockPosition();
        return Map.of("x", pos.getX(), "y", pos.getY(), "z", pos.getZ());
    }

    private void applyReply(Companion c, Wolf wolf, ServerPlayer owner, AISession session, OllamaClient.Reply reply) {
        long now = wolf.level().getGameTime();
        session.idleUntil = session.wanderUntil = session.lookUntil = session.fleeUntil = 0;
        switch (reply.action()) {
            case "follow" -> { cancelTrick(c); c.following = true; wolf.setOrderedToSit(false); save(); }
            case "stay" -> {
                cancelTrick(c);
                c.following = false; wolf.setOrderedToSit(true); wolf.setTarget(null);
                wolf.getNavigation().stop(); save();
            }
            case "idle" -> { session.idleUntil = now + 100; stopUnlessFleeing(c, wolf); }
            case "look_at_player" -> { session.lookUntil = now + 100; stopUnlessFleeing(c, wolf); }
            case "wander" -> session.wanderUntil = now + 100;
            case "flee" -> session.fleeUntil = now + 100;
            case "say" -> { }
            default -> { return; }
        }
        if (!reply.say().isBlank()) {
            owner.sendSystemMessage(Component.literal("<walk> " + reply.say()));
            c.nextMessage = now + 200;
        }
    }

    private void stopUnlessFleeing(Companion c, Wolf wolf) {
        if (!"FLEE".equals(c.action)) wolf.getNavigation().stop();
    }

    private void remember(Companion c, Entity entity, ServerLevel level) {
        c.dimension = level.dimension().identifier().toString();
        c.chunkX = entity.chunkPosition().x(); c.chunkZ = entity.chunkPosition().z();
    }

    private Path statePath() { return server.getWorldPath(LevelResource.ROOT).resolve("markai.json"); }

    private void save() {
        if (server == null || !storageHealthy) return;
        try {
            Path target = statePath(), temp = target.resolveSibling("markai.json.tmp");
            Files.writeString(temp, JSON.toJson(companions.values()));
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            storageHealthy = false;
            LOG.error("Cannot save MarkAI state; further commands disabled", e);
        }
    }
}
