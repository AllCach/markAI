package dev.markai.brain;

/**
 * Minimal decision logic for a configurable Minecraft companion.
 * This class is independent of Minecraft and Fabric APIs.
 */
public final class MarkBrain {

    private MarkBrain() {}

    public record WorldState(
        String playerName,
        double distanceToPlayer,
        double enemyDistance,
        int health
    ) {}

    public record Decision(
        String action,
        String message
    ) {}

    public static Decision think(WorldState world) {
        if (world == null) {
            throw new IllegalArgumentException("WorldState must not be null");
        }

        String name = world.playerName() == null || world.playerName().isBlank()
            ? "друг"
            : world.playerName();

        // No enemies nearby: supply Double.POSITIVE_INFINITY as enemyDistance.
        if (world.enemyDistance() < 6.0) {
            return new Decision("FLEE", name + ", БЛЯ, СПАСАЙ!");
        }

        if (world.distanceToPlayer() > 4.0) {
            return new Decision("FOLLOW", name + ", подожди меня!");
        }

        return new Decision("IDLE", "Чё делаем, " + name + "?");
    }
}
