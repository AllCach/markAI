package dev.markai.ai;

import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Local-only settings, loaded once when a logical server starts. */
public final class AIConfig {
    public String ollamaUrl = "http://127.0.0.1:11434";
    public String ollamaModel = "qwen3:8b";
    public int timeoutSeconds = 120;
    public int requestCooldownSeconds = 5;
    public boolean thinking = true;

    public static AIConfig load(Path path) throws IOException {
        var gson = new GsonBuilder().setPrettyPrinting().create();
        if (!Files.exists(path)) {
            Files.createDirectories(path.getParent());
            AIConfig config = new AIConfig();
            Files.writeString(path, gson.toJson(config));
            return config;
        }
        AIConfig config = gson.fromJson(Files.readString(path), AIConfig.class);
        if (config == null || !("qwen3:8b".equals(config.ollamaModel) || "qwen3:4b".equals(config.ollamaModel))
                || config.timeoutSeconds < 5 || config.timeoutSeconds > 120
                || config.requestCooldownSeconds < 2 || config.requestCooldownSeconds > 60) {
            throw new IOException("Invalid MarkAI config: use local qwen3:8b or qwen3:4b and valid limits");
        }
        return config;
    }
}
