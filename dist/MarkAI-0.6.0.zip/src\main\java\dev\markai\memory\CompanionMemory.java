package dev.markai.memory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.markai.ai.OllamaClient;
import java.util.*;

/** Bounded local memories: player reports remain quotes, events come from the game. */
public final class CompanionMemory {
    private static final Gson JSON = new GsonBuilder().disableHtmlEscaping().create();
    private record Report(String kind, String quote, long game_time) {}
    private record Event(String key, String text, long game_time) {}
    private List<OllamaClient.ChatMessage> conversation = new ArrayList<>();
    private List<Report> reports = new ArrayList<>();
    private List<Event> events = new ArrayList<>();

    public void normalize() {
        if (conversation == null) conversation = new ArrayList<>();
        if (reports == null) reports = new ArrayList<>();
        if (events == null) events = new ArrayList<>();
        reports.removeIf(r -> r == null || r.quote == null || r.quote.length() > 512 || r.kind == null);
        events.removeIf(e -> e == null || e.key == null || e.text == null || e.text.length() > 160);
        boolean valid = conversation.size() % 2 == 0;
        for (int i = 0; i < conversation.size() && valid; i++) {
            var m = conversation.get(i);
            valid = m != null && m.content() != null && m.content().length() <= 1024
                && (i % 2 == 0 ? "user" : "assistant").equals(m.role());
        }
        if (!valid) conversation.clear();
        trim();
    }

    public List<OllamaClient.ChatMessage> history() { return List.copyOf(conversation); }

    public void rememberExchange(String question, OllamaClient.Reply reply, long time) {
        if (question == null || question.isBlank() || question.length() > 512 || reply == null) return;
        conversation.add(new OllamaClient.ChatMessage("user", question));
        conversation.add(new OllamaClient.ChatMessage("assistant", JSON.toJson(reply)));
        rememberStatement(question, time);
        trim();
    }

    public void rememberStatement(String text, long time) {
        if (text == null || text.isBlank() || text.length() > 512) return;
        String lower = text.strip().toLowerCase(Locale.ROOT);
        String kind;
        if (lower.matches("^(?:я )?(?:хочу|планирую|собираюсь)(?=\\s|[,!:.]|$).*")) kind = "plan";
        else if (lower.matches("^(?:я люблю|мне нравится|я предпочитаю)(?=\\s|[,!:.]|$).*")) kind = "preference";
        else if (lower.matches("^(?:запомни|меня зовут|зови меня|мой |моя |моё |мое |у меня ).*")) kind = "fact";
        else return;
        reports.removeIf(r -> r.quote.equalsIgnoreCase(text));
        reports.add(new Report(kind, text, time));
        trim();
    }

    public void rememberEvent(String key, String text, long time) {
        if (key == null || text == null || text.isBlank()) return;
        key = key.toLowerCase(Locale.ROOT);
        if (text.length() > 160) text = text.substring(0, 160);
        for (int i = events.size() - 1; i >= 0; i--) {
            Event previous = events.get(i);
            if (previous.key.equals(key) && time >= previous.game_time && time - previous.game_time < 1200
                    && previous.text.equals(text)) return;
        }
        events.add(new Event(key, text, time));
        trim();
    }

    public Map<String, Object> context(String question) {
        var chosenReports = select(reports, question, 6);
        var chosenEvents = select(events, question, 4);
        Map<String, Object> context = Map.of("player_reports", chosenReports, "observed_events", chosenEvents);
        while (JSON.toJson(context).length() > 3000) {
            if (!chosenEvents.isEmpty()) chosenEvents.removeLast();
            else if (!chosenReports.isEmpty()) chosenReports.removeLast();
            else break;
        }
        return context;
    }

    private static <T> ArrayList<T> select(List<T> entries, String question, int count) {
        Set<String> terms = new HashSet<>(Arrays.asList((question == null ? "" : question)
            .toLowerCase(Locale.ROOT).replace('ё', 'е').split("[^\\p{L}\\p{N}]+")));
        terms.removeIf(t -> t.length() < 3 || Set.of("какой", "какая", "помнишь", "меня", "тебя", "мне", "что", "как").contains(t));
        var ranked = new ArrayList<Integer>();
        for (int i = 0; i < entries.size(); i++) ranked.add(i);
        ranked.sort(Comparator.<Integer>comparingInt(i -> {
            String text = entries.get(i).toString().toLowerCase(Locale.ROOT).replace('ё', 'е');
            return (int) terms.stream().filter(text::contains).count();
        }).reversed().thenComparing(Comparator.reverseOrder()));
        var result = new ArrayList<T>();
        for (int i : ranked.subList(0, Math.min(count, ranked.size()))) result.add(entries.get(i));
        return result;
    }

    public void clear() { conversation.clear(); reports.clear(); events.clear(); }

    private void trim() {
        while (conversation.size() > 24 || conversation.stream().mapToInt(m -> m.content().length()).sum() > 12000) {
            conversation.removeFirst(); conversation.removeFirst();
        }
        while (reports.size() > 48) reports.removeFirst();
        while (events.size() > 64) events.removeFirst();
    }
}
